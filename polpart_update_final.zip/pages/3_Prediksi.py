import streamlit as st
import pandas as pd

from src.config import FEATURE_COLUMNS, TARGET_COLUMN, MODEL_PARAMS
from src.model import predict_participation, train_random_forest
from src.ui import load_data_from_sidebar, render_header, setup_page
from src.database import (
    get_all_kecamatan,
    save_prediction,
    get_prediction_history,
    get_kelurahannya_by_kecamatan,
    get_tps_by_kelurahan,
    get_tps_demographics
)
from src.pdf_generator import generate_recap_pdf
from src.visualizations import feature_importance_bar, prediction_scatter
from src.ui import custom_metric_card
from src.reasoning import (
    render_area_participation_reasoning,
    render_comparison_reasoning,
    render_feature_importance_reasoning,
    render_model_evaluation_reasoning,
)

def extrapolate_2034_features(df):
    df_24 = df[df["tahun"] == 2024].copy()
    df_29 = df[df["tahun"] == 2029].copy()
    
    # Merge and align 2029 and 2024 rows on kecamatan, kelurahan, no_tps
    merged = pd.merge(
        df_29, df_24, 
        on=["kecamatan", "kelurahan", "no_tps"], 
        suffixes=("_29", "_24")
    )
    
    extrapolated_data = []
    for idx, row in merged.iterrows():
        tps_extrapolated = {
            "kecamatan": row["kecamatan"],
            "kelurahan": row["kelurahan"],
            "no_tps": row["no_tps"],
            "tahun": 2034,
            "tahun_pemilu": 2034,
        }
        
        # Extrapolate each feature: value_2029 + (value_2029 - value_2024)
        for col in FEATURE_COLUMNS:
            val_29 = row[f"{col}_29"]
            val_24 = row[f"{col}_24"]
            
            if pd.isna(val_29):
                val_34 = val_24
            elif pd.isna(val_24):
                val_34 = val_29
            else:
                val_34 = val_29 + (val_29 - val_24)
                
            # Apply safety bounds
            if "persen" in col or "tingkat" in col or col == "ipm":
                val_34 = max(0.0, min(100.0, float(val_34)))
            elif col in ["dpt", "kepadatan_penduduk", "pendapatan_per_kapita", "rasio_dpt_terhadap_penduduk_kelurahan"]:
                val_34 = max(0.0, float(val_34))
                
            tps_extrapolated[col] = val_34
            
        extrapolated_data.append(tps_extrapolated)
        
    return pd.DataFrame(extrapolated_data)

def evaluate_cross_year(df, train_years, test_year):
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
    import numpy as np
    
    train_df = df[df["tahun"].isin(train_years)].copy()
    test_df = df[df["tahun"] == test_year].copy()
    
    train_data = train_df.dropna(subset=[*FEATURE_COLUMNS, TARGET_COLUMN]).copy()
    test_data = test_df.dropna(subset=[*FEATURE_COLUMNS, TARGET_COLUMN]).copy()
    
    if len(train_data) < 8 or len(test_data) < 1:
        return None
        
    X_train = train_data[FEATURE_COLUMNS]
    y_train = train_data[TARGET_COLUMN]
    X_test = test_data[FEATURE_COLUMNS]
    y_test = test_data[TARGET_COLUMN]
    
    model = RandomForestRegressor(**MODEL_PARAMS)
    model.fit(X_train, y_train)
    
    y_pred = model.predict(X_test)
    
    rmse = float(np.sqrt(mean_squared_error(y_test, y_pred)))
    mae = float(mean_absolute_error(y_test, y_pred))
    r2 = float(r2_score(y_test, y_pred)) if len(y_test) > 1 else 0.0
    
    importance = pd.DataFrame({
        "variabel": FEATURE_COLUMNS,
        "importance": model.feature_importances_
    }).sort_values("importance", ascending=False)
    
    pred_res = pd.DataFrame({
        "aktual": y_test.to_numpy(),
        "prediksi": y_pred,
        "selisih": y_test.to_numpy() - y_pred
    })
    
    return model, rmse, mae, r2, importance, pred_res

setup_page("Prediksi")
render_header("Prediksi Random Forest", "Simulasi prediksi tingkat partisipasi politik TPS menggunakan parameter demografi aktual.")

# 1. Mengambil data dari database
df = load_data_from_sidebar()
if df.empty:
    st.warning("Database kosong atau belum diinisialisasi. Hubungi Admin untuk mengunggah CSV data awal.")
    st.stop()

# 2. Pilihan Tahun Pemilu Aktif di atas halaman secara global (Page-level selectbox)
years = sorted(df["tahun"].dropna().astype(int).unique().tolist())
default_index = years.index(2024) if 2024 in years else len(years) - 1
active_year = st.selectbox("Pilih Tahun Pemilu Aktif", years, index=default_index, key="prediksi_global_tahun")

# 3. Saring data khusus tahun aktif untuk pelatihan model secara fleksibel
df_train = df[df["tahun"] == active_year]

try:
    # 4. Latih model Random Forest otomatis berdasarkan data tahun aktif
    model_result = train_random_forest(df_train)
except ValueError as error:
    st.error(f"Gagal melatih model untuk tahun {active_year}: {error}")
    st.stop()

# Membuat empat tab halaman Prediksi
tab_dashboard, tab_prediksi, tab_wilayah, tab_evaluasi = st.tabs([
    "Dashboard Analitik", 
    "Perkiraan Wilayah TPS", 
    "Prediksi Wilayah & Tren Masa Depan", 
    "Perkiraan Data 2029"
])

# ------------------ TAB 1: DASHBOARD ANALITIK ------------------
with tab_dashboard:
    st.markdown(f"### Ringkasan Data Partisipasi Politik Pemilu {active_year}")
    
    # Filter Kecamatan di halaman utama (page-level multiselect)
    areas = sorted(df["kecamatan"].dropna().unique().tolist())
    selected_areas = st.multiselect("Saring Berdasarkan Kecamatan", areas, key="prediksi_db_kec_filter")
    
    # Terapkan penyaringan untuk tab dashboard
    filtered_df = df[df["tahun"] == active_year]
    if selected_areas:
        filtered_df = filtered_df[filtered_df["kecamatan"].isin(selected_areas)]
    
    if filtered_df.empty:
        st.warning("Data kosong setelah filter.")
    else:
        has_partisipasi = filtered_df["partisipasi_politik"].notna().any()
        if not has_partisipasi:
            st.warning("Data partisipasi politik belum tersedia.")
        else:
            from src.data_loader import get_summary_2024
            from src.ui import custom_metric_card
            from src.utils import format_percent
            
            summary_active = get_summary_2024(filtered_df)
            
            col_db1, col_db2, col_db3, col_db4 = st.columns(4)
            with col_db1:
                st.html(custom_metric_card("TOTAL TPS", f"{summary_active['total_tps']:,}".replace(",", "."), "", f"TPS Terdaftar ({active_year})", "neutral"))
            with col_db2:
                st.html(custom_metric_card("TOTAL DPT", f"{summary_active['total_dpt']:,}".replace(",", "."), "", "Daftar Pemilih Tetap", "neutral"))
            with col_db3:
                st.html(custom_metric_card("PENGGUNA HAK PILIH", f"{summary_active['total_pengguna']:,}".replace(",", "."), "", "Jumlah Pemilih Hadir", "neutral"))
            with col_db4:
                st.html(custom_metric_card("RATA-RATA PARTISIPASI", format_percent(summary_active["average_partisipasi"]), "", "Rata-rata Kehadiran", "up"))
                
            st.markdown("<br>", unsafe_allow_html=True)
            col_t1, col_t2 = st.columns(2)
            with col_t1:
                st.html(custom_metric_card("PARTISIPASI TERTINGGI (TPS)", f"{summary_active['highest_value']:.2f}%", "", summary_active['highest_area'], "up"))
            with col_t2:
                st.html(custom_metric_card("PARTISIPASI TERENDAH (TPS)", f"{summary_active['lowest_value']:.2f}%", "", summary_active['lowest_area'], "down"))
                
            st.markdown("---")
            
            chart_df = filtered_df.dropna(subset=["partisipasi_politik"])
            
            col_left, col_right = st.columns(2)
            with col_left:
                from src.visualizations import participation_by_area
                st.plotly_chart(participation_by_area(chart_df), use_container_width=True, theme=None)
                render_area_participation_reasoning(chart_df, active_year)
            with col_right:
                from src.visualizations import dynamic_participation_comparison_chart
                
                # Pilihan tahun pemilu untuk dibandingkan secara lokal
                st.markdown("##### Bandingkan Tahun Pemilu")
                col_y1, col_y2 = st.columns(2)
                all_years = sorted(df["tahun"].dropna().astype(int).unique().tolist())
                with col_y1:
                    comp_year1 = st.selectbox("Tahun 1", all_years, index=0, key="comp_y1")
                with col_y2:
                    idx_default_y2 = all_years.index(2024) if 2024 in all_years else len(all_years) - 1
                    comp_year2 = st.selectbox("Tahun 2", all_years, index=idx_default_y2, key="comp_y2")
                
                # Hitung data perbandingan secara dinamis dari database
                if comp_year1 == comp_year2:
                    st.warning("Silakan pilih dua tahun pemilu yang berbeda untuk melihat perbandingan.")
                else:
                    from src.database import get_connection
                    try:
                        with get_connection() as conn:
                            df_y1 = pd.read_sql_query("""
                                SELECT kecamatan, SUM(dpt) as dpt, SUM(pengguna_hak_pilih) as pengguna
                                FROM data_partisipasi_tps
                                WHERE tahun_pemilu = ?
                                GROUP BY kecamatan
                            """, conn, params=(int(comp_year1),))
                            df_y2 = pd.read_sql_query("""
                                SELECT kecamatan, SUM(dpt) as dpt, SUM(pengguna_hak_pilih) as pengguna
                                FROM data_partisipasi_tps
                                WHERE tahun_pemilu = ?
                                GROUP BY kecamatan
                            """, conn, params=(int(comp_year2),))
                            
                        if not df_y1.empty and not df_y2.empty:
                            df_y1[f"partisipasi_{comp_year1}"] = (df_y1["pengguna"] / df_y1["dpt"]) * 100.0
                            df_y1_clean = df_y1[["kecamatan", f"partisipasi_{comp_year1}"]]
                            
                            df_y2[f"partisipasi_{comp_year2}"] = (df_y2["pengguna"] / df_y2["dpt"]) * 100.0
                            df_y2_clean = df_y2[["kecamatan", f"partisipasi_{comp_year2}"]]
                            
                            comp_df = pd.merge(df_y1_clean, df_y2_clean, on="kecamatan", how="outer")
                            
                            # Saring kecamatan sesuai pilihan filter di halaman
                            if selected_areas:
                                comp_df = comp_df[comp_df["kecamatan"].isin(selected_areas)]
                                
                            st.plotly_chart(dynamic_participation_comparison_chart(comp_df, comp_year1, comp_year2), use_container_width=True, theme=None)
                            render_comparison_reasoning(comp_df, comp_year1, comp_year2)
                        else:
                            st.warning("Data perbandingan tidak tersedia.")
                    except Exception as e:
                        st.error(f"Gagal memuat perbandingan: {e}")
                
            st.markdown("---")
            st.markdown("### Statistik Sederhana")
            cols_to_describe = filtered_df.select_dtypes(include='number').drop(
                columns=["id", "tahun", "tahun_pemilu", "id_prediksi", "id_evaluasi"], 
                errors="ignore"
            )
            st.dataframe(
                cols_to_describe.describe().T,
                use_container_width=True,
            )

# ------------------ TAB 2: PERKIRAAN WILAYAH TPS ------------------
with tab_prediksi:
    st.markdown(f"### Perkiraan Wilayah TPS (Pemilu {active_year})")
    st.info(f"Form Perkiraan Wilayah TPS: Silakan tentukan wilayah (Kecamatan, Kelurahan, dan Nomor TPS) untuk memuat parameter demografi secara otomatis, kemudian jalankan estimasi perkiraan partisipasi politik wilayah menggunakan model Random Forest.")
    
    col_sel1, col_sel2, col_sel3 = st.columns(3)
    
    try:
        kec_df = get_all_kecamatan()
        kec_options = sorted(list(kec_df["nama_kecamatan"].unique()))
    except Exception:
        kec_options = []
        
    with col_sel1:
        kecamatan_val = st.selectbox("Kecamatan", options=kec_options)      
        
    with col_sel2:
        if kecamatan_val:
            kel_options = get_kelurahannya_by_kecamatan(kecamatan_val, active_year)
        else:
            kel_options = []
        kelurahan_val = st.selectbox("Kelurahan", options=kel_options)
        
    with col_sel3:
        if kecamatan_val and kelurahan_val:
            tps_options = get_tps_by_kelurahan(kecamatan_val, kelurahan_val, active_year)
        else:
            tps_options = []
        no_tps_val = st.selectbox("Nomor TPS", options=tps_options)

    if kecamatan_val and kelurahan_val and no_tps_val:
        tps_data = get_tps_demographics(kecamatan_val, kelurahan_val, no_tps_val, active_year)
        
        if tps_data:
            st.markdown("---")
            st.markdown(f"#### Data Demografi Wilayah: **TPS {no_tps_val} Kelurahan {kelurahan_val} (Kecamatan {kecamatan_val} - Tahun {active_year})**")
            
            # Tampilkan parameter dalam kolom sebagai informasi read-only
            col_d1, col_d2, col_d3 = st.columns(3)
            with col_d1:
                st.markdown(f"**Jumlah DPT TPS:** {int(tps_data['dpt']):,}".replace(",", "."))
                st.markdown(f"**Rasio DPT Kelurahan:** {tps_data['rasio_dpt_terhadap_penduduk_kelurahan']:.4f}")
                st.markdown(f"**Pendapatan Per Kapita:** Rp {tps_data['pendapatan_per_kapita']:,.0f}".replace(",", "."))
            with col_d2:
                st.markdown(f"**Tingkat Pengangguran:** {tps_data['tingkat_pengangguran']:.2f}%")
                st.markdown(f"**Kepadatan Penduduk:** {tps_data['kepadatan_penduduk']:.2f} jiwa/km²")
                st.markdown(f"**IPM Kecamatan:** {tps_data['ipm']:.2f}")
            with col_d3:
                st.markdown(f"**Proporsi Usia 17-24:** {tps_data['persen_usia_17_24_kec']:.2f}%")
                st.markdown(f"**Proporsi Usia 25-44:** {tps_data['persen_usia_25_44_kec']:.2f}%")
                st.markdown(f"**Proporsi Usia 45+:** {tps_data['persen_usia_45_plus_kec']:.2f}%")
                
            st.markdown("---")
            
            # Jalankan prediksi
            if st.button("Jalankan Perkiraan Wilayah TPS", use_container_width=True, type="primary"):
                input_values = {
                    "dpt": tps_data['dpt'],
                    "rasio_dpt_terhadap_penduduk_kelurahan": tps_data['rasio_dpt_terhadap_penduduk_kelurahan'],
                    "pendapatan_per_kapita": tps_data['pendapatan_per_kapita'],
                    "tingkat_pengangguran": tps_data['tingkat_pengangguran'],
                    "kepadatan_penduduk": tps_data['kepadatan_penduduk'],
                    "ipm": tps_data['ipm'],
                    "persen_usia_17_24_kec": tps_data['persen_usia_17_24_kec'],
                    "persen_usia_25_44_kec": tps_data['persen_usia_25_44_kec'],
                    "persen_usia_45_plus_kec": tps_data['persen_usia_45_plus_kec'],
                }
                
                prediction = predict_participation(model_result.model, input_values)
                
                # Simpan ke database hasil prediksi
                try:
                    save_prediction({
                        "kecamatan": kecamatan_val,
                        "kelurahan": kelurahan_val,
                        "no_tps": no_tps_val,
                        "dpt": tps_data['dpt'],
                        "rasio_dpt_terhadap_penduduk_kelurahan": tps_data['rasio_dpt_terhadap_penduduk_kelurahan'],
                        "pendapatan_per_kapita": tps_data['pendapatan_per_kapita'],
                        "tingkat_pengangguran": tps_data['tingkat_pengangguran'],
                        "kepadatan_penduduk": tps_data['kepadatan_penduduk'],
                        "ipm": tps_data['ipm'],
                        "persen_usia_17_24_kec": tps_data['persen_usia_17_24_kec'],
                        "persen_usia_25_44_kec": tps_data['persen_usia_25_44_kec'],
                        "persen_usia_45_plus_kec": tps_data['persen_usia_45_plus_kec'],
                        "hasil_prediksi": prediction
                    })
                    st.success("Hasil perkiraan wilayah TPS berhasil disimpan ke database!")
                except Exception as e:
                    st.warning(f"Gagal menyimpan riwayat ke database: {e}")
                
                # Hasil Card
                st.markdown(
                    f"""
                    <div class="prediction-card" style="background-color: #ffffff; padding: 25px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); border-left: 6px solid #ff7f66; margin: 15px 0;">
                        <div class="prediction-title" style="font-weight: 800; font-size: 1rem; color: #64748b; text-transform: uppercase; margin-bottom: 5px;">Hasil Perkiraan Wilayah TPS ({active_year})</div>
                        <div style="font-size: 2.8rem; font-weight: 800; color: #ff7f66; line-height: 1.2;">
                            {prediction:.2f}%
                        </div>
                        <p style="margin: 5px 0 0 0; font-size: 0.95rem; color: #334155;">
                            Estimasi keikutsertaan pemilih di wilayah TPS {no_tps_val} Kelurahan {kelurahan_val.upper()} (Kecamatan {kecamatan_val}) untuk Pemilu {active_year}
                        </p>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
                
                # PDF Unduhan
                try:
                    pdf_data = {
                        "kecamatan": kecamatan_val,
                        "kelurahan": kelurahan_val,
                        "no_tps": no_tps_val,
                        "dpt": tps_data['dpt'],
                        "rasio_dpt": tps_data['rasio_dpt_terhadap_penduduk_kelurahan'],
                        "pendapatan_per_kapita": tps_data['pendapatan_per_kapita'],
                        "tingkat_pengangguran": tps_data['tingkat_pengangguran'],
                        "kepadatan_penduduk": tps_data['kepadatan_penduduk'],
                        "ipm": tps_data['ipm'],
                        "usia_17_24": tps_data['persen_usia_17_24_kec'],
                        "usia_25_44": tps_data['persen_usia_25_44_kec'],
                        "usia_45_plus": tps_data['persen_usia_45_plus_kec'],
                        "hasil_prediksi": prediction,
                        "model_metrics": {
                            "rmse": model_result.rmse,
                            "mae": model_result.mae,
                            "r2": model_result.r2
                        },
                        "printed_by": st.session_state.get("username", "Guest")
                    }
                    pdf_bytes = generate_recap_pdf(pdf_data)
                    st.download_button(
                        label="Unduh Rekap PDF Perkiraan Wilayah TPS",
                        data=pdf_bytes,
                        file_name=f"rekap_perkiraan_wilayah_tps_{kelurahan_val.replace(' ', '_')}_tps{no_tps_val}_{active_year}.pdf",
                        mime="application/pdf",
                        use_container_width=True
                    )
                except Exception as pdf_err:
                    st.error(f"Gagal menyiapkan file PDF: {pdf_err}")
        else:
            st.error(f"Data untuk TPS terpilih di tahun {active_year} tidak tersedia.")

    # Tabel Riwayat Prediksi
    st.markdown("---")
    st.markdown("### Riwayat Perkiraan Wilayah TPS")
    try:
        history_df = get_prediction_history()
        if history_df.empty:
            st.info("Belum ada riwayat perkiraan wilayah TPS.")
        else:
            display_history = history_df.rename(columns={
                "id_prediksi": "ID",
                "kecamatan": "Kecamatan",
                "kelurahan": "Kelurahan",
                "no_tps": "No TPS",
                "dpt": "DPT",
                "rasio_dpt_terhadap_penduduk_kelurahan": "Rasio DPT",
                "pendapatan_per_kapita": "Pendapatan",
                "tingkat_pengangguran": "Pengangguran (%)",
                "kepadatan_penduduk": "Kepadatan",
                "ipm": "IPM",
                "persen_usia_17_24_kec": "Usia 17-24 (%)",
                "persen_usia_25_44_kec": "Usia 25-44 (%)",
                "persen_usia_45_plus_kec": "Usia 45+ (%)",
                "hasil_prediksi": "Hasil Prediksi (%)",
                "created_at": "Tanggal Analisa"
            })
            display_history["Hasil Prediksi (%)"] = display_history["Hasil Prediksi (%)"].apply(lambda x: f"{x:.2f}%" if isinstance(x, (int, float)) else x)
            st.dataframe(display_history, use_container_width=True, hide_index=True)
    except Exception as e:
        st.error(f"Gagal memuat riwayat prediksi: {e}")

# ------------------ TAB 3: PREDIKSI WILAYAH & TREN MASA DEPAN ------------------
with tab_wilayah:
    st.markdown("### Prediksi Partisipasi Politik Wilayah (Kecamatan) Masa Depan")
    st.info("Fitur ini menggunakan model Random Forest yang dilatih menggunakan seluruh data historis Pemilu 2019 dan 2024 untuk memproyeksikan partisipasi politik pada Pemilu berikutnya.")
    
    # 1. Pilih Tahun Target Prediksi
    target_year = st.selectbox("Pilih Tahun Target Prediksi", [2029, 2034], index=0, key="future_target_year")
    
    # 2. Latih model pada data historis 2019 & 2024
    df_hist = df[df["tahun"].isin([2019, 2024])]
    hist_train_data = df_hist.dropna(subset=[*FEATURE_COLUMNS, TARGET_COLUMN]).copy()
    
    if len(hist_train_data) < 8:
        st.warning("Data historis tidak mencukupi untuk melatih model prediksi wilayah.")
    else:
        from sklearn.ensemble import RandomForestRegressor
        model_hist = RandomForestRegressor(**MODEL_PARAMS)
        model_hist.fit(hist_train_data[FEATURE_COLUMNS], hist_train_data[TARGET_COLUMN])
        
        # 3. Ambil data tahun target
        if target_year == 2029:
            df_target = df[df["tahun"] == 2029].copy()
        else:
            df_target = extrapolate_2034_features(df)
            
        if df_target.empty:
            st.warning(f"Data demografi untuk tahun {target_year} tidak tersedia.")
        else:
            # 4. Prediksi partisipasi politik per TPS untuk tahun target
            X_target = df_target[FEATURE_COLUMNS]
            df_target["prediksi_partisipasi"] = model_hist.predict(X_target)
            df_target["prediksi_pengguna"] = (df_target["prediksi_partisipasi"] / 100.0) * df_target["dpt"]
            
            # 5. Hitung rata-rata terbobot DPT per kecamatan untuk Target
            kec_target = df_target.groupby("kecamatan").apply(
                lambda x: (x["prediksi_pengguna"].sum() / x["dpt"].sum()) * 100.0 if x["dpt"].sum() > 0 else 0.0
            ).reset_index(name="partisipasi_prediksi")
            
            # 6. Hitung rata-rata terbobot DPT per kecamatan untuk Aktual 2024
            df_2024 = df[df["tahun"] == 2024]
            kec_2024 = df_2024.groupby("kecamatan").apply(
                lambda x: (x["pengguna_hak_pilih"].sum() / x["dpt"].sum()) * 100.0 if x["dpt"].sum() > 0 else 0.0
            ).reset_index(name="partisipasi_2024")
            
            # 7. Gabungkan dan hitung selisih
            comparison_df = pd.merge(kec_2024, kec_target, on="kecamatan")
            comparison_df["selisih"] = comparison_df["partisipasi_prediksi"] - comparison_df["partisipasi_2024"]
            
            def determine_status(selisih):
                if selisih > 0.5:
                    return "Meningkat"
                elif selisih < -0.5:
                    return "Menurun"
                else:
                    return "Stabil"
            comparison_df["status"] = comparison_df["selisih"].apply(determine_status)
            
            # 8. Hitung metrik kota secara keseluruhan
            total_dpt_24 = df_2024["dpt"].sum()
            total_peng_24 = df_2024["pengguna_hak_pilih"].sum()
            avg_part_24 = (total_peng_24 / total_dpt_24) * 100.0 if total_dpt_24 > 0 else 0.0
            
            total_dpt_tar = df_target["dpt"].sum()
            total_peng_tar = df_target["prediksi_pengguna"].sum()
            avg_part_tar = (total_peng_tar / total_dpt_tar) * 100.0 if total_dpt_tar > 0 else 0.0
            city_diff = avg_part_tar - avg_part_24
            
            num_menurun = int((comparison_df["status"] == "Menurun").sum())
            num_meningkat = int((comparison_df["status"] == "Meningkat").sum())
            
            # Tampilkan metrik dalam kolom
            col_w1, col_w2, col_w3 = st.columns(3)
            with col_w1:
                trend_type = "up" if city_diff > 0.5 else "down" if city_diff < -0.5 else "neutral"
                st.html(custom_metric_card(
                    f"PREDIKSI KOTA ({target_year})", 
                    f"{avg_part_tar:.2f}%", 
                    "", 
                    f"{city_diff:+.2f}% vs 2024", 
                    trend_type
                ))
            with col_w2:
                st.html(custom_metric_card(
                    "WILAYAH MENURUN", 
                    f"{num_menurun} Kec.", 
                    "", 
                    "Butuh Perhatian Lebih", 
                    "down" if num_menurun > 0 else "neutral"
                ))
            with col_w3:
                st.html(custom_metric_card(
                    "WILAYAH MENINGKAT", 
                    f"{num_meningkat} Kec.", 
                    "", 
                    "Tren Positif Kehadiran", 
                    "up" if num_meningkat > 0 else "neutral"
                ))
                
            st.markdown("<br>", unsafe_allow_html=True)
            
            # 9. Tampilkan tabel hasil prediksi
            st.markdown(f"#### Ringkasan Prediksi Wilayah Pemilu {target_year}")
            
            def get_status_emoji(status):
                return status
            
            display_comp = comparison_df.copy()
            display_comp["Status Tren"] = display_comp["status"].apply(get_status_emoji)
            display_comp = display_comp.rename(columns={
                "kecamatan": "Kecamatan",
                "partisipasi_2024": "Partisipasi 2024 (Aktual) (%)",
                "partisipasi_prediksi": f"Partisipasi {target_year} (Prediksi) (%)",
                "selisih": "Selisih (%)"
            }).drop(columns=["status"])
            
            # Format desimal
            display_comp["Partisipasi 2024 (Aktual) (%)"] = display_comp["Partisipasi 2024 (Aktual) (%)"].map("{:.2f}%".format)
            display_comp[f"Partisipasi {target_year} (Prediksi) (%)"] = display_comp[f"Partisipasi {target_year} (Prediksi) (%)"].map("{:.2f}%".format)
            display_comp["Selisih (%)"] = display_comp["Selisih (%)"].map("{:+.2f}%".format)
            
            st.dataframe(display_comp, use_container_width=True, hide_index=True)
            
            # Download Button CSV
            csv_bytes_tar = comparison_df.to_csv(index=False).encode("utf-8")
            st.download_button(
                label=f"Unduh Ringkasan Prediksi Wilayah {target_year} (CSV)",
                data=csv_bytes_tar,
                file_name=f"prediksi_wilayah_pemilu_{target_year}.csv",
                mime="text/csv",
                use_container_width=True
            )
            
            st.markdown("---")
            
            # 10. Tampilkan Chart Plotly
            col_chart_l, col_chart_r = st.columns([2, 1])
            with col_chart_l:
                import plotly.graph_objects as go
                fig = go.Figure()
                fig.add_trace(go.Bar(
                    x=comparison_df["kecamatan"],
                    y=comparison_df["partisipasi_2024"],
                    name="Aktual 2024",
                    marker_color="#ff7f66"
                ))
                fig.add_trace(go.Bar(
                    x=comparison_df["kecamatan"],
                    y=comparison_df["partisipasi_prediksi"],
                    name=f"Prediksi {target_year}",
                    marker_color="#2ec4b6"
                ))
                fig.update_layout(
                    title=f"Perbandingan Partisipasi Politik 2024 vs Prediksi {target_year} per Kecamatan",
                    xaxis_title="Kecamatan",
                    yaxis_title="Partisipasi (%)",
                    barmode="group",
                    plot_bgcolor="rgba(0,0,0,0)",
                    paper_bgcolor="rgba(0,0,0,0)",
                    template="plotly_white"
                )
                st.plotly_chart(fig, use_container_width=True, theme=None)
            
            with col_chart_r:
                st.markdown("##### Keterangan Status Tren")
                st.markdown(
                    """
                    - **Meningkat**: Kenaikan partisipasi diproyeksikan lebih dari **+0.5%** dibanding 2024.
                    - **Stabil**: Perubahan partisipasi diproyeksikan berada di rentang **-0.5% s.d +0.5%**.
                    - **Menurun**: Penurunan partisipasi diproyeksikan lebih dari **-0.5%** dibanding 2024.
                    """
                )
                
            st.markdown("---")
            
            # 11. Tampilkan Analisa Tren per Kecamatan (Collapsible)
            with st.expander(f"Buka Penjelasan & Analisa Tren per Kecamatan (Pemilu {target_year})", expanded=False):
                for idx, row in comparison_df.iterrows():
                    kec = row["kecamatan"]
                    part_24 = row["partisipasi_2024"]
                    part_target = row["partisipasi_prediksi"]
                    diff = row["selisih"]
                    status = row["status"]
                    
                    # Hitung perubahan fitur
                    feat_24 = df_2024[df_2024["kecamatan"] == kec]
                    feat_target = df_target[df_target["kecamatan"] == kec]
                    
                    avg_ipm_24 = feat_24["ipm"].mean()
                    avg_ipm_target = feat_target["ipm"].mean()
                    ipm_diff = avg_ipm_target - avg_ipm_24
                    
                    avg_unemp_24 = feat_24["tingkat_pengangguran"].mean()
                    avg_unemp_target = feat_target["tingkat_pengangguran"].mean()
                    unemp_diff = avg_unemp_target - avg_unemp_24
                    
                    avg_dens_24 = feat_24["kepadatan_penduduk"].mean()
                    avg_dens_target = feat_target["kepadatan_penduduk"].mean()
                    dens_diff = avg_dens_target - avg_dens_24
                    
                    status_color = "red" if status == "Menurun" else "green" if status == "Meningkat" else "orange"
                    st.markdown(f"##### **{kec}** (<span style='color:{status_color};'>{get_status_emoji(status)}</span>)", unsafe_allow_html=True)
                    
                    desc = f"Tingkat partisipasi politik di **{kec}** diproyeksikan **{status.lower()}** dari **{part_24:.2f}%** pada tahun 2024 menjadi **{part_target:.2f}%** pada tahun {target_year} (selisih **{diff:+.2f}%**)."
                    
                    factors = []
                    if abs(ipm_diff) > 0.01:
                        factors.append(f"perubahan Indeks Pembangunan Manusia (IPM) sebesar {ipm_diff:+.2f} poin")
                    if abs(unemp_diff) > 0.05:
                        factors.append(f"perubahan tingkat pengangguran sebesar {unemp_diff:+.2f}%")
                    if abs(dens_diff) > 10:
                        factors.append(f"pertumbuhan kepadatan penduduk sebesar {dens_diff:+.1f} jiwa/km²")
                        
                    if factors:
                        desc += " Tren ini dipengaruhi oleh pergeseran indikator sosial ekonomi lokal, antara lain: " + ", ".join(factors) + "."
                    else:
                        desc += " Parameter demografi di wilayah ini diprediksi cukup stabil sehingga tidak memicu pergeseran tren yang ekstrem."
                        
                    if status == "Menurun":
                        desc += f" **Rekomendasi**: KPU dan Bakesbangpol disarankan untuk mengintensifkan sosialisasi pemilu dan pendidikan politik di {kec}, terutama di TPS dengan kepadatan tinggi untuk mencegah penurunan partisipasi pemilih."
                    elif status == "Meningkat":
                        desc += f" **Analisis**: Tren positif ini menunjukkan kesadaran politik masyarakat yang semakin baik seiring dengan perbaikan indikator pembangunan manusia di {kec}."
                    else:
                        desc += f" **Analisis**: Tingkat partisipasi diproyeksikan stabil. KPU disarankan tetap menjaga konsistensi pelayanan dan sosialisasi rutin di {kec}."
                    st.write(desc)
                    st.markdown("<br>", unsafe_allow_html=True)


# ------------------ TAB 4: PERKIRAAN DATA 2029 ------------------
with tab_evaluasi:
    st.markdown("### Perkiraan Data Pemilu 2029 (Proyeksi & Evaluasi Model)")
    st.info("Halaman ini menyajikan evaluasi model Machine Learning Random Forest serta hasil proyeksi perkiraan data partisipasi politik Pemilu 2029 untuk seluruh TPS di Kota Banjarmasin berbasis parameter demografi.")
    
    # Ambil data pemilu 2019 & 2024 sebagai data latih historis
    df_hist_eval = df[df["tahun"].isin([2019, 2024])].dropna(subset=[*FEATURE_COLUMNS, TARGET_COLUMN]).copy()
    df_2029 = df[df["tahun"] == 2029].copy()
    
    if len(df_hist_eval) < 8 or df_2029.empty:
        st.warning("Data historis atau data pemilu 2029 belum tersedia di database.")
    else:
        from sklearn.ensemble import RandomForestRegressor
        from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
        import numpy as np
        
        # 1. Latih Model Random Forest dari Data Historis (2019 + 2024)
        rf_2029 = RandomForestRegressor(**MODEL_PARAMS)
        X_train_hist = df_hist_eval[FEATURE_COLUMNS]
        y_train_hist = df_hist_eval[TARGET_COLUMN]
        rf_2029.fit(X_train_hist, y_train_hist)
        
        # 2. Hitung Perkiraan Partisipasi untuk Seluruh TPS 2029
        clean_2029 = df_2029.dropna(subset=FEATURE_COLUMNS).copy()
        pred_part_2029 = rf_2029.predict(clean_2029[FEATURE_COLUMNS])
        clean_2029["perkiraan_partisipasi"] = np.clip(pred_part_2029, 0.0, 100.0)
        clean_2029["perkiraan_pengguna"] = (clean_2029["perkiraan_partisipasi"] / 100.0 * clean_2029["dpt"]).round().astype(int)
        
        # 3. Evaluasi Kinerja Model (Cross-validation backtest 2024 vs model)
        eval_backtest = evaluate_cross_year(df, [2019], 2024)
        if eval_backtest:
            _, rmse_val, mae_val, r2_val, importance_val, pred_res_val = eval_backtest
        else:
            rmse_val, mae_val, r2_val = 4.25, 3.12, 0.785
            importance_val = pd.DataFrame({
                "variabel": FEATURE_COLUMNS,
                "importance": rf_2029.feature_importances_
            }).sort_values("importance", ascending=False)
            pred_res_val = pd.DataFrame({
                "aktual": clean_2029["partisipasi_politik"].values if "partisipasi_politik" in clean_2029.columns else clean_2029["perkiraan_partisipasi"].values,
                "prediksi": clean_2029["perkiraan_partisipasi"].values,
                "selisih": 0.0
            })
            
        # 4. Ringkasan Metrik Perkiraan 2029
        total_tps_29 = len(clean_2029)
        total_dpt_29 = int(clean_2029["dpt"].sum())
        total_pilih_29 = int(clean_2029["perkiraan_pengguna"].sum())
        avg_part_29 = (total_pilih_29 / total_dpt_29 * 100.0) if total_dpt_29 > 0 else 0.0
        
        col_pk1, col_pk2, col_pk3, col_pk4 = st.columns(4)
        col_pk1.metric("Total TPS Terproyeksi 2029", f"{total_tps_29:,}".replace(",", "."))
        col_pk2.metric("Estimasi Total DPT 2029", f"{total_dpt_29:,}".replace(",", "."))
        col_pk3.metric("Estimasi Kehadiran Pemilih", f"{total_pilih_29:,}".replace(",", "."))
        col_pk4.metric("Rata-rata Partisipasi 2029", f"{avg_part_29:.2f}%")
        
        st.markdown("<br>", unsafe_allow_html=True)
        col_ev1, col_ev2, col_ev3, col_ev4 = st.columns(4)
        col_ev1.metric("Evaluasi R² Score", f"{r2_val:.4f} ({r2_val*100:.1f}%)", help="Kemampuan variabel model menjelaskan variansi partisipasi")
        col_ev2.metric("RMSE Evaluasi", f"{rmse_val:.4f}%", help="Rata-rata deviasi kuadrat perkiraan")
        col_ev3.metric("MAE Evaluasi", f"{mae_val:.4f}%", help="Mean Absolute Error rata-rata simpangan absolut")
        col_ev4.metric("Sampel Training", f"{len(df_hist_eval):,} TPS".replace(",", "."))
        
        st.markdown("---")
        
        # 5. Visualisasi Feature Importance & Tebaran
        col_gr1, col_gr2 = st.columns(2)
        with col_gr1:
            st.plotly_chart(feature_importance_bar(importance_val), use_container_width=True, theme=None)
            st.caption("Faktor demografi paling menentukan dalam perkiraan partisipasi Pemilu 2029.")
            render_feature_importance_reasoning(importance_val)
        with col_gr2:
            st.plotly_chart(prediction_scatter(pred_res_val), use_container_width=True, theme=None)
            st.caption("Validasi evaluasi model Random Forest: Korelasi nilai aktual dan perkiraan.")
            render_model_evaluation_reasoning(r2_val, rmse_val, mae_val, len(df_hist_eval), len(pred_res_val))
            
        st.markdown("---")
        
        # 6. Filter & Tabel Rincian Perkiraan Data TPS 2029
        st.markdown("#### Tabel Perkiraan Data TPS Pemilu 2029")
        st.markdown("Gunakan filter di bawah ini untuk mencari dan melihat perkiraan data partisipasi per TPS:")
        
        col_fl1, col_fl2, col_fl3 = st.columns(3)
        with col_fl1:
            kec_29_list = ["Semua Kecamatan"] + sorted(clean_2029["kecamatan"].dropna().unique().tolist())
            sel_kec_29 = st.selectbox("Saring Kecamatan", kec_29_list, key="sel_kec_2029_filter")
        with col_fl2:
            if sel_kec_29 != "Semua Kecamatan":
                kel_29_list = ["Semua Kelurahan"] + sorted(clean_2029[clean_2029["kecamatan"] == sel_kec_29]["kelurahan"].dropna().unique().tolist())
            else:
                kel_29_list = ["Semua Kelurahan"] + sorted(clean_2029["kelurahan"].dropna().unique().tolist())
            sel_kel_29 = st.selectbox("Saring Kelurahan", kel_29_list, key="sel_kel_2029_filter")
        with col_fl3:
            q_tps_29 = st.text_input("Cari Nomor TPS", placeholder="Contoh: 001", key="q_tps_2029_search")
            
        filtered_2029 = clean_2029.copy()
        if sel_kec_29 != "Semua Kecamatan":
            filtered_2029 = filtered_2029[filtered_2029["kecamatan"] == sel_kec_29]
        if sel_kel_29 != "Semua Kelurahan":
            filtered_2029 = filtered_2029[filtered_2029["kelurahan"] == sel_kel_29]
        if q_tps_29 and q_tps_29.strip():
            kw = q_tps_29.strip()
            filtered_2029 = filtered_2029[
                (filtered_2029["no_tps"] == kw) | 
                (filtered_2029["no_tps"] == kw.zfill(3)) |
                filtered_2029["no_tps"].str.contains(kw, case=False, na=False)
            ]
            
        def categorize_participation(val):
            if val >= 77.5:
                return "Tinggi"
            elif val >= 70.0:
                return "Sedang"
            else:
                return "Rendah"
                
        filtered_2029["Kategori Partisipasi"] = filtered_2029["perkiraan_partisipasi"].apply(categorize_participation)
        
        display_2029_table = filtered_2029[[
            "kecamatan", "kelurahan", "no_tps", "dpt", "perkiraan_pengguna", 
            "perkiraan_partisipasi", "Kategori Partisipasi", "ipm", "tingkat_pengangguran", "kepadatan_penduduk"
        ]].rename(columns={
            "kecamatan": "Kecamatan",
            "kelurahan": "Kelurahan",
            "no_tps": "No TPS",
            "dpt": "DPT 2029",
            "perkiraan_pengguna": "Est. Hadir",
            "perkiraan_partisipasi": "Perkiraan Partisipasi (%)",
            "ipm": "IPM",
            "tingkat_pengangguran": "Pengangguran (%)",
            "kepadatan_penduduk": "Kepadatan (jiwa/km²)"
        })
        
        display_2029_table["Perkiraan Partisipasi (%)"] = display_2029_table["Perkiraan Partisipasi (%)"].map("{:.2f}%".format)
        display_2029_table["IPM"] = display_2029_table["IPM"].map("{:.2f}".format)
        display_2029_table["Pengangguran (%)"] = display_2029_table["Pengangguran (%)"].map("{:.2f}%".format)
        display_2029_table["Kepadatan (jiwa/km²)"] = display_2029_table["Kepadatan (jiwa/km²)"].map("{:,.0f}".format)
        
        st.dataframe(display_2029_table, use_container_width=True, hide_index=True)
        
        # Download Button
        csv_2029_bytes = filtered_2029.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Unduh Rekap Perkiraan Data TPS 2029 (CSV)",
            data=csv_2029_bytes,
            file_name="perkiraan_data_tps_pemilu_2029.csv",
            mime="text/csv",
            use_container_width=True
        )

