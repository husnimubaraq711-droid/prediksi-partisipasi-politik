import streamlit as st
import pandas as pd
import sqlite3

from src.ui import render_header, setup_page, custom_metric_card
from src.config import DB_PATH
from src.database import (
    get_connection,
    get_database_summary_stats,
    check_database_integrity,
    get_all_kecamatan,
    add_kecamatan,
    update_kecamatan,
    delete_kecamatan,
    get_all_kelurahan,
    add_kelurahan,
    update_kelurahan,
    delete_kelurahan,
    get_all_master_tps,
    add_master_tps,
    update_master_tps,
    delete_master_tps,
    get_all_dapil,
    add_dapil,
    update_dapil,
    delete_dapil,
    get_all_pemilu,
    add_pemilu,
    update_pemilu,
    delete_pemilu,
    get_all_pengguna,
    add_pengguna,
    update_pengguna,
    delete_pengguna,
    get_kelurahannya_by_kecamatan,
    get_tps_by_kelurahan,
    get_tps_demographics,
    add_tps_record,
    update_tps_record,
    delete_tps_record,
    add_partai,
    delete_partai,
    update_partai,
    get_all_data_agregat,
    add_data_agregat,
    update_data_agregat,
    delete_data_agregat,
    get_prediction_history,
    delete_prediction,
    clear_all_predictions,
    get_all_model_evaluations,
    delete_model_evaluation,
    seed_relational_tables_from_tps
)

def render_export_and_template_buttons(df: pd.DataFrame, entity_name: str, template_cols: list[str], sample_row: dict = None):
    """Helper untuk merender tombol unduh data tabel dan template CSV resmi."""
    col_e1, col_e2 = st.columns(2)
    with col_e1:
        if not df.empty:
            csv_data = df.to_csv(index=False).encode('utf-8')
            st.download_button(
                f"Unduh Data {entity_name} (CSV)",
                data=csv_data,
                file_name=f"export_{entity_name.lower().replace(' ', '_')}.csv",
                mime="text/csv",
                use_container_width=True
            )
    with col_e2:
        template_df = pd.DataFrame([sample_row or {col: '' for col in template_cols}])
        tpl_csv = template_df.to_csv(index=False).encode('utf-8')
        st.download_button(
            f"Unduh Template Format {entity_name} (CSV)",
            data=tpl_csv,
            file_name=f"template_{entity_name.lower().replace(' ', '_')}.csv",
            mime="text/csv",
            use_container_width=True
        )

setup_page("Kelola Data")

# Check role access
if st.session_state.get("role") not in ["admin", "kpu"]:
    st.error("Akses Ditolak: Anda tidak memiliki izin untuk mengakses halaman manajemen data.")
    st.stop()

render_header("Kelola Data Sistem", "Pusat Manajemen Basis Data Relasional: Master Data, Data Transaksi, dan Sinkronisasi.")

# --------------------------------------------------------------------
# RINGKASAN INDIKATOR STATUS BASIS DATA RELASIONAL
# --------------------------------------------------------------------
db_stats = get_database_summary_stats()
col_met1, col_met2, col_met3, col_met4 = st.columns(4)
with col_met1:
    st.html(custom_metric_card("MASTER DATA", "7 Entitas", "", f"{db_stats['master_kecamatan']} Kec | {db_stats['master_kelurahan']} Kel | {db_stats['master_tps']} TPS", "neutral"))
with col_met2:
    st.html(custom_metric_card("DATA TRANSAKSI", "5 Entitas", "", f"{db_stats['transaksi_tps']:,} TPS | {db_stats['transaksi_suara_partai']:,} Suara".replace(",", "."), "neutral"))
with col_met3:
    st.html(custom_metric_card("INTEGRITAS RELASI", "Terverifikasi", "", "Foreign Keys Enforced (ON)", "up"))
with col_met4:
    user_role = str(st.session_state.get("role", "Admin")).upper()
    st.html(custom_metric_card("OTORISASI AKSES", user_role, "", "Pusat Kendali Relasional", "neutral"))

st.markdown("<br>", unsafe_allow_html=True)


# --------------------------------------------------------------------
# NAVIGASI RESOURCE (CLEAN ENTERPRISE CRUD STYLE)
# --------------------------------------------------------------------
col_nav1, col_nav2 = st.columns([1, 2])

with col_nav1:
    kategori_pilihan = st.selectbox(
        "Kategori Modul:",
        ["Master Data (7 Entitas)", "Data Transaksi (5 Entitas)", "Pusat Impor & Sinkronisasi"],
        key="kelola_kategori_sel"
    )

with col_nav2:
    if kategori_pilihan == "Master Data (7 Entitas)":
        modul_pilihan = st.selectbox(
            "Pilih Entitas Master:",
            [
                "Master Kecamatan",
                "Master Kelurahan",
                "Master Titik TPS",
                "Master Dapil",
                "Master Partai Politik",
                "Master Periode Pemilu",
                "Master Pengguna / Akun Sistem"
            ],
            key="kelola_master_modul_sel"
        )
    elif kategori_pilihan == "Data Transaksi (5 Entitas)":
        modul_pilihan = st.selectbox(
            "Pilih Entitas Transaksi:",
            [
                "Transaksi Partisipasi Pemilu TPS",
                "Transaksi Perolehan Suara Partai",
                "Transaksi Partisipasi Agregat",
                "Transaksi Log Hasil Prediksi",
                "Transaksi Log Evaluasi Model"
            ],
            key="kelola_trans_modul_sel"
        )
    else:
        modul_pilihan = "Pusat Impor & Sinkronisasi"

# Kelola State Tampilan (Index vs Create vs Edit)
if "last_active_modul" not in st.session_state or st.session_state["last_active_modul"] != modul_pilihan:
    st.session_state["last_active_modul"] = modul_pilihan
    st.session_state["crud_view"] = "index"
    st.session_state["edit_target_id"] = None

def set_view(view_name, target_id=None):
    st.session_state["crud_view"] = view_name
    st.session_state["edit_target_id"] = target_id
    st.rerun()

crud_view = st.session_state.get("crud_view", "index")
edit_id = st.session_state.get("edit_target_id", None)

st.markdown("---")


# ====================================================================
# MODUL 1: MASTER KECAMATAN
# ====================================================================
if modul_pilihan == "Master Kecamatan":
    df_kec = get_all_kecamatan()
    
    # --- VIEW: CREATE ---
    if crud_view == "create":
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
                
        st.markdown("### Form Tambah Master Kecamatan")
        st.caption("Pendaftaran wilayah kecamatan baru ke dalam basis data master.")
        
        with st.form("form_create_kecamatan"):
            nama_kec = st.text_input("Nama Kecamatan", placeholder="Contoh: BANJARMASIN SELATAN").strip().upper()
            c_sub1, c_sub2 = st.columns(2)
            with c_sub1:
                submit_btn = st.form_submit_button("Simpan Data", use_container_width=True, type="primary")
            with c_sub2:
                cancel_btn = st.form_submit_button("Batal", use_container_width=True)
                
            if submit_btn:
                if not nama_kec:
                    st.error("Nama kecamatan wajib diisi.")
                elif add_kecamatan(nama_kec):
                    st.success(f"Kecamatan '{nama_kec}' berhasil ditambahkan.")
                    set_view("index")
                else:
                    st.error("Gagal menambahkan. Nama kecamatan tersebut sudah terdaftar.")
            if cancel_btn:
                set_view("index")

    # --- VIEW: EDIT ---
    elif crud_view == "edit" and edit_id is not None:
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
                
        row_cur = df_kec[df_kec["id_kecamatan"] == edit_id]
        if row_cur.empty:
            st.error("Data tidak ditemukan.")
            set_view("index")
        else:
            cur_data = row_cur.iloc[0]
            st.markdown(f"### Form Edit Master Kecamatan (ID: {edit_id})")
            
            with st.form("form_edit_kecamatan"):
                nama_kec_edit = st.text_input("Nama Kecamatan", value=str(cur_data["nama_kecamatan"])).strip().upper()
                c_sub1, c_sub2 = st.columns(2)
                with c_sub1:
                    submit_upd = st.form_submit_button("Simpan Perubahan", use_container_width=True, type="primary")
                with c_sub2:
                    cancel_upd = st.form_submit_button("Batal", use_container_width=True)
                    
                if submit_upd:
                    if not nama_kec_edit:
                        st.error("Nama kecamatan wajib diisi.")
                    elif update_kecamatan(edit_id, nama_kec_edit):
                        st.success("Perubahan data kecamatan berhasil disimpan.")
                        set_view("index")
                    else:
                        st.error("Gagal memperbarui data kecamatan.")
                if cancel_upd:
                    set_view("index")

    # --- VIEW: INDEX (TABEL UTAMA) ---
    else:
        c_title, c_btn = st.columns([3, 1])
        with c_title:
            st.markdown("### Master Data Kecamatan")
            st.caption("Entitas induk wilayah tingkat 1 Kota Banjarmasin.")
        with c_btn:
            if st.button("Tambah Kecamatan", type="primary", use_container_width=True):
                set_view("create")
                
        if df_kec.empty:
            st.info("Belum ada data kecamatan terdaftar.")
        else:
            display_df = df_kec.rename(columns={"id_kecamatan": "ID", "nama_kecamatan": "Nama Kecamatan"})
            st.dataframe(display_df, use_container_width=True, hide_index=True)
            st.caption(f"Total: **{len(df_kec)} Kecamatan Terdaftar**")
            render_export_and_template_buttons(
                df_kec,
                "Kecamatan",
                ["nama_kecamatan"],
                {"nama_kecamatan": "BANJARMASIN SELATAN"}
            )
            
            # Action Bar
            st.markdown("---")
            st.markdown("##### Aksi untuk Baris Terpilih:")
            c_sel, c_ed, c_del = st.columns([3, 1, 1])
            with c_sel:
                kec_opts = {f"{r['nama_kecamatan']} (ID: {r['id_kecamatan']})": r['id_kecamatan'] for _, r in df_kec.iterrows()}
                pilih_id = st.selectbox("Pilih Kecamatan:", list(kec_opts.keys()), label_visibility="collapsed")
                target_id = kec_opts[pilih_id]
            with c_ed:
                if st.button("Edit Data", use_container_width=True):
                    set_view("edit", target_id)
            with c_del:
                if st.button("Hapus Data", type="primary", use_container_width=True):
                    if delete_kecamatan(target_id):
                        st.success("Kecamatan berhasil dihapus.")
                        st.rerun()
                    else:
                        st.error("Gagal menghapus kecamatan.")


# ====================================================================
# MODUL 2: MASTER KELURAHAN
# ====================================================================
elif modul_pilihan == "Master Kelurahan":
    df_kel = get_all_kelurahan()
    df_kec = get_all_kecamatan()
    kec_dict = {r["nama_kecamatan"]: r["id_kecamatan"] for _, r in df_kec.iterrows()}
    
    # --- VIEW: CREATE ---
    if crud_view == "create":
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
                
        st.markdown("### Form Tambah Master Kelurahan")
        if not kec_dict:
            st.warning("Master Kecamatan masih kosong. Tambahkan kecamatan terlebih dahulu.")
        else:
            with st.form("form_create_kelurahan"):
                nama_kel = st.text_input("Nama Kelurahan", placeholder="Contoh: BASIRIH").strip().upper()
                kec_induk = st.selectbox("Kecamatan Induk", list(kec_dict.keys()))
                c_sub1, c_sub2 = st.columns(2)
                with c_sub1:
                    sub_btn = st.form_submit_button("Simpan Kelurahan", use_container_width=True, type="primary")
                with c_sub2:
                    can_btn = st.form_submit_button("Batal", use_container_width=True)
                    
                if sub_btn:
                    if not nama_kel:
                        st.error("Nama kelurahan wajib diisi.")
                    elif add_kelurahan(nama_kel, kec_dict[kec_induk]):
                        st.success(f"Kelurahan '{nama_kel}' berhasil ditambahkan ke Kecamatan {kec_induk}.")
                        set_view("index")
                    else:
                        st.error("Gagal menambahkan. Kelurahan tersebut sudah terdaftar.")
                if can_btn:
                    set_view("index")

    # --- VIEW: EDIT ---
    elif crud_view == "edit" and edit_id is not None:
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
                
        row_cur = df_kel[df_kel["id_kelurahan"] == edit_id]
        if row_cur.empty:
            st.error("Data tidak ditemukan.")
            set_view("index")
        else:
            cur_data = row_cur.iloc[0]
            st.markdown(f"### Form Edit Master Kelurahan (ID: {edit_id})")
            
            with st.form("form_edit_kelurahan"):
                nama_kel_edit = st.text_input("Nama Kelurahan", value=str(cur_data["nama_kelurahan"])).strip().upper()
                idx_kec = list(kec_dict.keys()).index(cur_data["nama_kecamatan"]) if cur_data["nama_kecamatan"] in kec_dict else 0
                kec_induk_edit = st.selectbox("Kecamatan Induk", list(kec_dict.keys()), index=idx_kec)
                c_sub1, c_sub2 = st.columns(2)
                with c_sub1:
                    sub_upd = st.form_submit_button("Simpan Perubahan", use_container_width=True, type="primary")
                with c_sub2:
                    can_upd = st.form_submit_button("Batal", use_container_width=True)
                    
                if sub_upd:
                    if not nama_kel_edit:
                        st.error("Nama kelurahan wajib diisi.")
                    elif update_kelurahan(edit_id, nama_kel_edit, kec_dict[kec_induk_edit]):
                        st.success("Perubahan data kelurahan berhasil disimpan.")
                        set_view("index")
                    else:
                        st.error("Gagal memperbarui data kelurahan.")
                if can_upd:
                    set_view("index")

    # --- VIEW: INDEX ---
    else:
        c_title, c_btn = st.columns([3, 1])
        with c_title:
            st.markdown("### Master Data Kelurahan")
            st.caption("Entitas induk wilayah tingkat 2 Kota Banjarmasin.")
        with c_btn:
            if st.button("Tambah Kelurahan", type="primary", use_container_width=True):
                set_view("create")
                
        # Filter & Pencarian
        c_fl, c_sc = st.columns([1, 2])
        with c_fl:
            f_kec = st.selectbox("Filter Kecamatan:", ["Semua Kecamatan"] + list(kec_dict.keys()))
        with c_sc:
            q_kel = st.text_input("Cari Kelurahan:", placeholder="Ketik nama kelurahan...")
            
        display_df = df_kel.copy()
        if f_kec != "Semua Kecamatan":
            display_df = display_df[display_df["nama_kecamatan"] == f_kec]
        if q_kel and q_kel.strip():
            display_df = display_df[display_df["nama_kelurahan"].str.contains(q_kel.strip(), case=False, na=False)]
            
        st.dataframe(
            display_df[["id_kelurahan", "nama_kelurahan", "nama_kecamatan"]].rename(columns={
                "id_kelurahan": "ID", "nama_kelurahan": "Nama Kelurahan", "nama_kecamatan": "Kecamatan Induk"
            }),
            use_container_width=True,
            hide_index=True
        )
        st.caption(f"Menampilkan: **{len(display_df)} dari {len(df_kel)} Kelurahan Terdaftar**")
        render_export_and_template_buttons(
            display_df,
            "Kelurahan",
            ["nama_kelurahan", "id_kecamatan"],
            {"nama_kelurahan": "KELAYAN BARAT", "id_kecamatan": 1}
        )
        
        # Action Bar
        if not display_df.empty:
            st.markdown("---")
            st.markdown("##### Aksi untuk Baris Terpilih:")
            c_sel, c_ed, c_del = st.columns([3, 1, 1])
            with c_sel:
                kel_opts = {f"{r['nama_kelurahan']} ({r['nama_kecamatan']}) - ID: {r['id_kelurahan']}": r['id_kelurahan'] for _, r in display_df.iterrows()}
                pilih_id = st.selectbox("Pilih Kelurahan:", list(kel_opts.keys()), label_visibility="collapsed")
                target_id = kel_opts[pilih_id]
            with c_ed:
                if st.button("Edit Data", use_container_width=True):
                    set_view("edit", target_id)
            with c_del:
                if st.button("Hapus Data", type="primary", use_container_width=True):
                    if delete_kelurahan(target_id):
                        st.success("Kelurahan berhasil dihapus.")
                        st.rerun()
                    else:
                        st.error("Gagal menghapus kelurahan.")


# ====================================================================
# MODUL 3: MASTER TITIK TPS
# ====================================================================
elif modul_pilihan == "Master Titik TPS":
    df_mtps = get_all_master_tps()
    df_kel = get_all_kelurahan()
    kel_dict = {f"{r['nama_kelurahan']} ({r['nama_kecamatan']})": r["id_kelurahan"] for _, r in df_kel.iterrows()}
    
    # --- VIEW: CREATE ---
    if crud_view == "create":
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
                
        st.markdown("### Form Registrasi Titik TPS Baru")
        if not kel_dict:
            st.warning("Master Kelurahan masih kosong.")
        else:
            with st.form("form_create_mtps"):
                no_tps = st.text_input("Nomor TPS (3 Digit)", placeholder="Contoh: 001 atau 015").strip()
                kel_induk = st.selectbox("Pilih Kelurahan", list(kel_dict.keys()))
                c_sub1, c_sub2 = st.columns(2)
                with c_sub1:
                    sub_btn = st.form_submit_button("Simpan TPS", use_container_width=True, type="primary")
                with c_sub2:
                    can_btn = st.form_submit_button("Batal", use_container_width=True)
                    
                if sub_btn:
                    if not no_tps:
                        st.error("Nomor TPS wajib diisi.")
                    elif add_master_tps(no_tps, kel_dict[kel_induk]):
                        st.success(f"Titik TPS {no_tps} berhasil didaftarkan di {kel_induk}.")
                        set_view("index")
                    else:
                        st.error("Gagal mendaftarkan. Nomor TPS tersebut sudah terdaftar di kelurahan ini.")
                if can_btn:
                    set_view("index")

    # --- VIEW: EDIT ---
    elif crud_view == "edit" and edit_id is not None:
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
                
        row_cur = df_mtps[df_mtps["id_tps"] == edit_id]
        if row_cur.empty:
            st.error("Data tidak ditemukan.")
            set_view("index")
        else:
            cur_data = row_cur.iloc[0]
            st.markdown(f"### Form Edit Titik TPS (ID: {edit_id})")
            
            with st.form("form_edit_mtps"):
                no_tps_edit = st.text_input("Nomor TPS", value=str(cur_data["no_tps"])).strip()
                current_kel_label = f"{cur_data['nama_kelurahan']} ({cur_data['nama_kecamatan']})"
                idx_kel = list(kel_dict.keys()).index(current_kel_label) if current_kel_label in kel_dict else 0
                kel_induk_edit = st.selectbox("Pilih Kelurahan", list(kel_dict.keys()), index=idx_kel)
                c_sub1, c_sub2 = st.columns(2)
                with c_sub1:
                    sub_upd = st.form_submit_button("Simpan Perubahan", use_container_width=True, type="primary")
                with c_sub2:
                    can_upd = st.form_submit_button("Batal", use_container_width=True)
                    
                if sub_upd:
                    if not no_tps_edit:
                        st.error("Nomor TPS wajib diisi.")
                    elif update_master_tps(edit_id, no_tps_edit, kel_dict[kel_induk_edit]):
                        st.success("Perubahan data TPS berhasil disimpan.")
                        set_view("index")
                    else:
                        st.error("Gagal memperbarui TPS.")
                if can_upd:
                    set_view("index")

    # --- VIEW: INDEX ---
    else:
        c_title, c_btn = st.columns([3, 1])
        with c_title:
            st.markdown("### Master Data Titik TPS")
            st.caption("Daftar titik Tempat Pemungutan Suara resmi Kota Banjarmasin.")
        with c_btn:
            if st.button("Tambah Titik TPS", type="primary", use_container_width=True):
                set_view("create")
                
        # Filter & Search
        c_f1, c_f2 = st.columns([1, 2])
        with c_f1:
            all_kecs = ["Semua Kecamatan"] + sorted(list(df_mtps["nama_kecamatan"].dropna().unique()))
            f_kec_tps = st.selectbox("Filter Kecamatan:", all_kecs)
        with c_f2:
            q_tps = st.text_input("Cari Nomor TPS / Kelurahan:", placeholder="Contoh: 001 atau Basirih")
            
        display_df = df_mtps.copy()
        if f_kec_tps != "Semua Kecamatan":
            display_df = display_df[display_df["nama_kecamatan"] == f_kec_tps]
        if q_tps and q_tps.strip():
            kw = q_tps.strip()
            display_df = display_df[
                display_df["no_tps"].str.contains(kw, case=False, na=False) |
                display_df["nama_kelurahan"].str.contains(kw, case=False, na=False)
            ]
            
        st.dataframe(
            display_df[["id_tps", "no_tps", "nama_kelurahan", "nama_kecamatan"]].rename(columns={
                "id_tps": "ID", "no_tps": "No TPS", "nama_kelurahan": "Kelurahan", "nama_kecamatan": "Kecamatan"
            }),
            use_container_width=True,
            hide_index=True
        )
        st.caption(f"Menampilkan: **{len(display_df):,} dari {len(df_mtps):,} Titik TPS Terdaftar**".replace(",", "."))
        render_export_and_template_buttons(
            display_df,
            "Titik TPS",
            ["no_tps", "id_kelurahan"],
            {"no_tps": "001", "id_kelurahan": 1}
        )
        
        # Action Bar
        if not display_df.empty:
            st.markdown("---")
            st.markdown("##### Aksi untuk Baris Terpilih:")
            c_sel, c_ed, c_del = st.columns([3, 1, 1])
            with c_sel:
                tps_opts = {f"TPS {r['no_tps']} - Kel. {r['nama_kelurahan']} (ID: {r['id_tps']})": r['id_tps'] for _, r in display_df.head(200).iterrows()}
                pilih_id = st.selectbox("Pilih Titik TPS:", list(tps_opts.keys()), label_visibility="collapsed")
                target_id = tps_opts[pilih_id]
            with c_ed:
                if st.button("Edit Data", use_container_width=True):
                    set_view("edit", target_id)
            with c_del:
                if st.button("Hapus Data", type="primary", use_container_width=True):
                    if delete_master_tps(target_id):
                        st.success("Titik TPS berhasil dihapus.")
                        st.rerun()
                    else:
                        st.error("Gagal menghapus TPS.")


# ====================================================================
# MODUL 4: MASTER DAPIL
# ====================================================================
elif modul_pilihan == "Master Dapil":
    df_dapil = get_all_dapil()
    
    if crud_view == "create":
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
        st.markdown("### Form Tambah Master Dapil")
        with st.form("form_create_dapil"):
            nama_dapil = st.text_input("Nama Dapil", placeholder="Contoh: BANJARMASIN 1").strip().upper()
            cakupan = st.text_input("Wilayah Cakupan", placeholder="Contoh: Kecamatan Banjarmasin Tengah").strip()
            c_sub1, c_sub2 = st.columns(2)
            with c_sub1:
                sub_btn = st.form_submit_button("Simpan Dapil", use_container_width=True, type="primary")
            with c_sub2:
                can_btn = st.form_submit_button("Batal", use_container_width=True)
            if sub_btn:
                if not nama_dapil:
                    st.error("Nama dapil wajib diisi.")
                elif add_dapil(nama_dapil, cakupan):
                    st.success(f"Dapil '{nama_dapil}' berhasil ditambahkan.")
                    set_view("index")
                else:
                    st.error("Gagal menambahkan dapil.")
            if can_btn:
                set_view("index")

    elif crud_view == "edit" and edit_id is not None:
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
        row_cur = df_dapil[df_dapil["id_dapil"] == edit_id]
        if row_cur.empty:
            set_view("index")
        else:
            cur_data = row_cur.iloc[0]
            st.markdown(f"### Form Edit Master Dapil (ID: {edit_id})")
            with st.form("form_edit_dapil"):
                nama_dapil_upd = st.text_input("Nama Dapil", value=str(cur_data["nama_dapil"])).strip().upper()
                cakupan_upd = st.text_input("Wilayah Cakupan", value=str(cur_data["wilayah_cakupan"])).strip()
                c_sub1, c_sub2 = st.columns(2)
                with c_sub1:
                    sub_upd = st.form_submit_button("Simpan Perubahan", use_container_width=True, type="primary")
                with c_sub2:
                    can_upd = st.form_submit_button("Batal", use_container_width=True)
                if sub_upd:
                    if not nama_dapil_upd:
                        st.error("Nama dapil wajib diisi.")
                    elif update_dapil(edit_id, nama_dapil_upd, cakupan_upd):
                        st.success("Perubahan dapil berhasil disimpan.")
                        set_view("index")
                    else:
                        st.error("Gagal memperbarui dapil.")
                if can_upd:
                    set_view("index")

    else:
        c_title, c_btn = st.columns([3, 1])
        with c_title:
            st.markdown("### Master Daerah Pemilihan (Dapil)")
            st.caption("Pembagian daerah pemilihan legislatif DPRD Kota Banjarmasin.")
        with c_btn:
            if st.button("Tambah Dapil", type="primary", use_container_width=True):
                set_view("create")
                
        st.dataframe(
            df_dapil.rename(columns={"id_dapil": "ID", "nama_dapil": "Nama Dapil", "wilayah_cakupan": "Wilayah Cakupan"}),
            use_container_width=True,
            hide_index=True
        )
        st.caption(f"Total: **{len(df_dapil)} Dapil Terdaftar**")
        render_export_and_template_buttons(
            df_dapil,
            "Dapil",
            ["nama_dapil", "wilayah_cakupan"],
            {"nama_dapil": "BANJARMASIN 1", "wilayah_cakupan": "Kecamatan Banjarmasin Tengah"}
        )
        
        if not df_dapil.empty:
            st.markdown("---")
            st.markdown("##### Aksi untuk Baris Terpilih:")
            c_sel, c_ed, c_del = st.columns([3, 1, 1])
            with c_sel:
                dapil_opts = {f"{r['nama_dapil']} (ID: {r['id_dapil']})": r['id_dapil'] for _, r in df_dapil.iterrows()}
                pilih_id = st.selectbox("Pilih Dapil:", list(dapil_opts.keys()), label_visibility="collapsed")
                target_id = dapil_opts[pilih_id]
            with c_ed:
                if st.button("Edit Data", use_container_width=True):
                    set_view("edit", target_id)
            with c_del:
                if st.button("Hapus Data", type="primary", use_container_width=True):
                    if delete_dapil(target_id):
                        st.success("Dapil berhasil dihapus.")
                        st.rerun()
                    else:
                        st.error("Gagal menghapus dapil.")


# ====================================================================
# MODUL 5: MASTER PARTAI POLITIK
# ====================================================================
elif modul_pilihan == "Master Partai Politik":
    with sqlite3.connect(DB_PATH) as conn:
        df_partai = pd.read_sql_query("SELECT id_partai, nomor_urut, singkatan, nama_partai FROM partai ORDER BY nomor_urut ASC", conn)
        
    if crud_view == "create":
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
        st.markdown("### Form Tambah Partai Politik")
        with st.form("form_create_partai"):
            no_urut = st.number_input("Nomor Urut Partai", min_value=1, max_value=100, value=1)
            singkatan = st.text_input("Singkatan Partai", placeholder="Contoh: GOLKAR").strip().upper()
            nama_partai = st.text_input("Nama Lengkap Partai", placeholder="Contoh: Partai Golongan Karya").strip()
            c_sub1, c_sub2 = st.columns(2)
            with c_sub1:
                sub_btn = st.form_submit_button("Simpan Partai", use_container_width=True, type="primary")
            with c_sub2:
                can_btn = st.form_submit_button("Batal", use_container_width=True)
            if sub_btn:
                if not singkatan or not nama_partai:
                    st.error("Singkatan dan nama lengkap partai wajib diisi.")
                elif add_partai(nama_partai, singkatan, no_urut):
                    st.success(f"Partai {singkatan} berhasil ditambahkan.")
                    set_view("index")
                else:
                    st.error("Gagal menambahkan. Singkatan atau nomor urut bentrok.")
            if can_btn:
                set_view("index")

    elif crud_view == "edit" and edit_id is not None:
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
        row_cur = df_partai[df_partai["id_partai"] == edit_id]
        if row_cur.empty:
            set_view("index")
        else:
            cur_data = row_cur.iloc[0]
            st.markdown(f"### Form Edit Partai Politik (ID: {edit_id})")
            with st.form("form_edit_partai"):
                no_urut_upd = st.number_input("Nomor Urut", min_value=1, value=int(cur_data["nomor_urut"]))
                singkatan_upd = st.text_input("Singkatan", value=str(cur_data["singkatan"])).strip().upper()
                nama_partai_upd = st.text_input("Nama Lengkap Partai", value=str(cur_data["nama_partai"])).strip()
                c_sub1, c_sub2 = st.columns(2)
                with c_sub1:
                    sub_upd = st.form_submit_button("Simpan Perubahan", use_container_width=True, type="primary")
                with c_sub2:
                    can_upd = st.form_submit_button("Batal", use_container_width=True)
                if sub_upd:
                    if not singkatan_upd or not nama_partai_upd:
                        st.error("Semua field wajib diisi.")
                    elif update_partai(edit_id, nama_partai_upd, singkatan_upd, no_urut_upd):
                        st.success("Perubahan data partai berhasil disimpan.")
                        set_view("index")
                    else:
                        st.error("Gagal memperbarui data partai.")
                if can_upd:
                    set_view("index")

    else:
        c_title, c_btn = st.columns([3, 1])
        with c_title:
            st.markdown("### Master Data Partai Politik")
            st.caption("Daftar partai politik resmi peserta pemilu.")
        with c_btn:
            if st.button("Tambah Partai", type="primary", use_container_width=True):
                set_view("create")
                
        st.dataframe(
            df_partai.rename(columns={"nomor_urut": "No Urut", "singkatan": "Singkatan", "nama_partai": "Nama Lengkap Partai"}),
            use_container_width=True,
            hide_index=True
        )
        st.caption(f"Total: **{len(df_partai)} Partai Terdaftar**")
        render_export_and_template_buttons(
            df_partai,
            "Partai",
            ["nama_partai", "singkatan", "nomor_urut"],
            {"nama_partai": "Partai Contoh", "singkatan": "PC", "nomor_urut": 1}
        )
        
        if not df_partai.empty:
            st.markdown("---")
            st.markdown("##### Aksi untuk Baris Terpilih:")
            c_sel, c_ed, c_del = st.columns([3, 1, 1])
            with c_sel:
                partai_opts = {f"No. {r['nomor_urut']} - {r['singkatan']} ({r['nama_partai']})": r['id_partai'] for _, r in df_partai.iterrows()}
                pilih_id = st.selectbox("Pilih Partai:", list(partai_opts.keys()), label_visibility="collapsed")
                target_id = partai_opts[pilih_id]
            with c_ed:
                if st.button("Edit Data", use_container_width=True):
                    set_view("edit", target_id)
            with c_del:
                if st.button("Hapus Data", type="primary", use_container_width=True):
                    if delete_partai(target_id):
                        st.success("Partai berhasil dihapus.")
                        st.rerun()
                    else:
                        st.error("Gagal menghapus partai.")


# ====================================================================
# MODUL 6: MASTER PERIODE PEMILU
# ====================================================================
elif modul_pilihan == "Master Periode Pemilu":
    df_pemilu = get_all_pemilu()
    
    if crud_view == "create":
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
        st.markdown("### Form Tambah Periode Pemilu")
        with st.form("form_create_pemilu"):
            tahun_p = st.number_input("Tahun Pemilu", min_value=1999, max_value=2050, value=2029)
            jenis_p = st.text_input("Keterangan Pemilu", value="Pemilu Serentak (Pileg & Pilpres)").strip()
            status_p = st.selectbox("Status Pelaksanaan", ["Tidak Aktif (0)", "Aktif Saat Ini (1)"])
            c_sub1, c_sub2 = st.columns(2)
            with c_sub1:
                sub_btn = st.form_submit_button("Simpan Periode", use_container_width=True, type="primary")
            with c_sub2:
                can_btn = st.form_submit_button("Batal", use_container_width=True)
            if sub_btn:
                val_st = 1 if "1" in status_p else 0
                if add_pemilu(tahun_p, jenis_p, val_st):
                    st.success(f"Periode Pemilu {tahun_p} berhasil ditambahkan.")
                    set_view("index")
                else:
                    st.error("Gagal: Periode pemilu sudah ada.")
            if can_btn:
                set_view("index")

    elif crud_view == "edit" and edit_id is not None:
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
        row_cur = df_pemilu[df_pemilu["id_pemilu"] == edit_id]
        if row_cur.empty:
            set_view("index")
        else:
            cur_data = row_cur.iloc[0]
            st.markdown(f"### Form Edit Periode Pemilu (ID: {edit_id})")
            with st.form("form_edit_pemilu"):
                tahun_upd = st.number_input("Tahun Pemilu", min_value=1999, max_value=2050, value=int(cur_data["tahun_pemilu"]))
                jenis_upd = st.text_input("Keterangan Pemilu", value=str(cur_data["jenis_pemilu"])).strip()
                status_upd = st.selectbox("Status", ["Tidak Aktif (0)", "Aktif Saat Ini (1)"], index=int(cur_data["status_aktif"]))
                c_sub1, c_sub2 = st.columns(2)
                with c_sub1:
                    sub_upd = st.form_submit_button("Simpan Perubahan", use_container_width=True, type="primary")
                with c_sub2:
                    can_upd = st.form_submit_button("Batal", use_container_width=True)
                if sub_upd:
                    val_st = 1 if "1" in status_upd else 0
                    if update_pemilu(edit_id, tahun_upd, jenis_upd, val_st):
                        st.success("Periode pemilu berhasil diperbarui.")
                        set_view("index")
                    else:
                        st.error("Gagal memperbarui periode pemilu.")
                if can_upd:
                    set_view("index")

    else:
        c_title, c_btn = st.columns([3, 1])
        with c_title:
            st.markdown("### Master Periode Pemilu")
            st.caption("Daftar agenda pelaksanaan pemilu.")
        with c_btn:
            if st.button("Tambah Periode", type="primary", use_container_width=True):
                set_view("create")
                
        disp_pem = df_pemilu.copy()
        disp_pem["Status"] = disp_pem["status_aktif"].apply(lambda x: "Aktif" if x == 1 else "Non-Aktif")
        st.dataframe(
            disp_pem[["id_pemilu", "tahun_pemilu", "jenis_pemilu", "Status"]].rename(columns={
                "id_pemilu": "ID", "tahun_pemilu": "Tahun", "jenis_pemilu": "Keterangan"
            }),
            use_container_width=True,
            hide_index=True
        )
        st.caption(f"Total: **{len(df_pemilu)} Periode Pemilu**")
        render_export_and_template_buttons(
            df_pemilu,
            "Periode Pemilu",
            ["tahun_pemilu", "jenis_pemilu", "status_aktif"],
            {"tahun_pemilu": 2024, "jenis_pemilu": "Pemilu Serentak", "status_aktif": 1}
        )
        
        if not df_pemilu.empty:
            st.markdown("---")
            st.markdown("##### Aksi untuk Baris Terpilih:")
            c_sel, c_ed, c_del = st.columns([3, 1, 1])
            with c_sel:
                pem_opts = {f"Pemilu {r['tahun_pemilu']} ({r['jenis_pemilu']})": r['id_pemilu'] for _, r in df_pemilu.iterrows()}
                pilih_id = st.selectbox("Pilih Periode:", list(pem_opts.keys()), label_visibility="collapsed")
                target_id = pem_opts[pilih_id]
            with c_ed:
                if st.button("Edit Data", use_container_width=True):
                    set_view("edit", target_id)
            with c_del:
                if st.button("Hapus Data", type="primary", use_container_width=True):
                    if delete_pemilu(target_id):
                        st.success("Periode pemilu berhasil dihapus.")
                        st.rerun()
                    else:
                        st.error("Gagal menghapus periode.")


# ====================================================================
# MODUL 7: MASTER PENGGUNA SISTEM
# ====================================================================
elif modul_pilihan == "Master Pengguna / Akun Sistem":
    df_users = get_all_pengguna()
    roles_list = ["admin", "kpu", "bakesbangpol", "bps", "dukcapil", "user"]
    
    if crud_view == "create":
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
        st.markdown("### Form Tambah Akun Pengguna")
        with st.form("form_create_user"):
            usr = st.text_input("Username", placeholder="Contoh: operator_kpu").strip().lower()
            pwd = st.text_input("Kata Sandi", type="password").strip()
            role_usr = st.selectbox("Peran (Role)", roles_list, index=1)
            c_sub1, c_sub2 = st.columns(2)
            with c_sub1:
                sub_btn = st.form_submit_button("Simpan Akun", use_container_width=True, type="primary")
            with c_sub2:
                can_btn = st.form_submit_button("Batal", use_container_width=True)
            if sub_btn:
                if not usr or not pwd:
                    st.error("Username dan password wajib diisi.")
                elif add_pengguna(usr, pwd, role_usr):
                    st.success(f"Akun '{usr}' berhasil didaftarkan.")
                    set_view("index")
                else:
                    st.error(f"Gagal: Username '{usr}' sudah digunakan.")
            if can_btn:
                set_view("index")

    elif crud_view == "edit" and edit_id is not None:
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
        row_cur = df_users[df_users["id_pengguna"] == edit_id]
        if row_cur.empty:
            set_view("index")
        else:
            cur_data = row_cur.iloc[0]
            st.markdown(f"### Form Edit Akun Pengguna: **{cur_data['username']}**")
            with st.form("form_edit_user"):
                idx_r = roles_list.index(cur_data["role"]) if cur_data["role"] in roles_list else 0
                role_upd = st.selectbox("Peran Akses", roles_list, index=idx_r)
                pwd_upd = st.text_input("Kata Sandi Baru (Kosongkan bila tidak diubah)", type="password").strip()
                c_sub1, c_sub2 = st.columns(2)
                with c_sub1:
                    sub_upd = st.form_submit_button("Simpan Perubahan", use_container_width=True, type="primary")
                with c_sub2:
                    can_upd = st.form_submit_button("Batal", use_container_width=True)
                if sub_upd:
                    if update_pengguna(edit_id, role_upd, pwd_upd if pwd_upd else None):
                        st.success("Akun berhasil diperbarui.")
                        set_view("index")
                    else:
                        st.error("Gagal memperbarui akun.")
                if can_upd:
                    set_view("index")

    else:
        c_title, c_btn = st.columns([3, 1])
        with c_title:
            st.markdown("### Master Pengguna Sistem & Hak Akses")
            st.caption("Daftar akun login dan kontrol hak akses pengguna.")
        with c_btn:
            if st.button("Tambah Akun", type="primary", use_container_width=True):
                set_view("create")
                
        st.dataframe(
            df_users.rename(columns={"id_pengguna": "ID", "username": "Username", "role": "Role Akses", "created_at": "Waktu Dibuat"}),
            use_container_width=True,
            hide_index=True
        )
        st.caption(f"Total: **{len(df_users)} Pengguna Terdaftar**")
        render_export_and_template_buttons(
            df_users,
            "Pengguna",
            ["username", "password", "role"],
            {"username": "petugas_kpu", "password": "password123", "role": "kpu"}
        )
        
        if not df_users.empty:
            st.markdown("---")
            st.markdown("##### Aksi untuk Baris Terpilih:")
            c_sel, c_ed, c_del = st.columns([3, 1, 1])
            with c_sel:
                u_opts = {f"{r['username']} ({r['role']}) - ID: {r['id_pengguna']}": r['id_pengguna'] for _, r in df_users.iterrows()}
                pilih_id = st.selectbox("Pilih Akun:", list(u_opts.keys()), label_visibility="collapsed")
                target_id = u_opts[pilih_id]
            with c_ed:
                if st.button("Edit Data", use_container_width=True):
                    set_view("edit", target_id)
            with c_del:
                row_sel = df_users[df_users["id_pengguna"] == target_id].iloc[0]
                if row_sel["username"] == "admin":
                    st.caption("Akun utama 'admin' tidak dapat dihapus.")
                else:
                    if st.button("Hapus Data", type="primary", use_container_width=True):
                        if delete_pengguna(target_id):
                            st.success("Akun berhasil dihapus.")
                            st.rerun()
                        else:
                            st.error("Gagal menghapus akun.")


# ====================================================================
# MODUL 8: TRANSAKSI PARTISIPASI TPS
# ====================================================================
elif modul_pilihan == "Transaksi Partisipasi Pemilu TPS":
    kec_options = ["BANJARMASIN BARAT", "BANJARMASIN SELATAN", "BANJARMASIN TIMUR", "BANJARMASIN TENGAH", "BANJARMASIN UTARA"]
    
    # --- VIEW: CREATE ---
    if crud_view == "create":
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
                
        st.markdown("### Form Input Transaksi Partisipasi TPS")
        with st.form("form_create_tps_trans"):
            c1, c2 = st.columns(2)
            with c1:
                t_th = st.selectbox("Tahun Pemilu", [2019, 2024, 2029], index=1)
                t_kc = st.selectbox("Kecamatan", kec_options)
                t_kl = st.text_input("Kelurahan", value="BASIRIH").strip().upper()
                t_no = st.text_input("Nomor TPS (3 Digit)", value="001").strip()
                t_dpt = st.number_input("Jumlah DPT TPS", min_value=1, value=250)
                t_pl = st.number_input("Pengguna Hak Pilih (Hadir)", min_value=0, value=200)
                t_rs = st.number_input("Rasio DPT Kelurahan", min_value=0.0, value=1.20, step=0.01)
                t_pnd = st.number_input("Pendapatan Per Kapita (Rp)", min_value=0.0, value=66989407.0, step=10000.0)
            with c2:
                t_png = st.number_input("Tingkat Pengangguran (%)", min_value=0.0, value=6.56, step=0.01)
                t_kpd = st.number_input("Kepadatan Penduduk (jiwa/km²)", min_value=0.0, value=10550.43, step=10.0)
                t_ipm = st.number_input("IPM", min_value=0.0, value=80.53, step=0.01)
                t_u1 = st.number_input("Pemilih Usia 17-24 (%)", min_value=0.0, value=13.6, step=0.1)
                t_u2 = st.number_input("Pemilih Usia 25-44 (%)", min_value=0.0, value=29.7, step=0.1)
                t_u3 = st.number_input("Pemilih Usia 45+ (%)", min_value=0.0, value=32.2, step=0.1)
            c_sub1, c_sub2 = st.columns(2)
            with c_sub1:
                sub_btn = st.form_submit_button("Simpan Transaksi TPS", use_container_width=True, type="primary")
            with c_sub2:
                can_btn = st.form_submit_button("Batal", use_container_width=True)
                
            if sub_btn:
                if not t_kl or not t_no:
                    st.error("Kelurahan dan Nomor TPS wajib diisi.")
                elif t_pl > t_dpt:
                    st.error("Pengguna hak pilih tidak boleh melebihi DPT.")
                else:
                    new_data = {
                        "tahun_pemilu": t_th, "kecamatan": t_kc, "kelurahan": t_kl, "no_tps": t_no,
                        "dpt": t_dpt, "pengguna_hak_pilih": t_pl, "rasio_dpt_terhadap_penduduk_kelurahan": t_rs,
                        "pendapatan_per_kapita": t_pnd, "tingkat_pengangguran": t_png, "kepadatan_penduduk": t_kpd,
                        "ipm": t_ipm, "persen_usia_17_24_kec": t_u1, "persen_usia_25_44_kec": t_u2, "persen_usia_45_plus_kec": t_u3
                    }
                    if add_tps_record(new_data):
                        st.success(f"Rekaman transaksi TPS {t_no} Kelurahan {t_kl} ({t_th}) berhasil disimpan.")
                        set_view("index")
                    else:
                        st.error("Gagal menyimpan transaksi TPS.")
            if can_btn:
                set_view("index")

    # --- VIEW: EDIT ---
    elif crud_view == "edit" and edit_id is not None:
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
                
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM data_partisipasi_tps WHERE id = ?", (edit_id,))
            row_raw = c.fetchone()
            
        if not row_raw:
            st.error("Data transaksi tidak ditemukan.")
            set_view("index")
        else:
            cur_tps = dict(row_raw)
            st.markdown(f"### Form Edit Transaksi TPS {cur_tps['no_tps']} Kel. {cur_tps['kelurahan']} ({cur_tps['tahun_pemilu']})")
            
            with st.form("form_edit_tps_trans"):
                c1, c2 = st.columns(2)
                with c1:
                    e_th = st.selectbox("Tahun Pemilu", [2019, 2024, 2029], index=[2019, 2024, 2029].index(cur_tps["tahun_pemilu"]))
                    e_dpt = st.number_input("Jumlah DPT TPS", min_value=1, value=int(cur_tps["dpt"]))
                    e_pl = st.number_input("Pengguna Hak Pilih", min_value=0, value=int(cur_tps["pengguna_hak_pilih"]))
                    e_rs = st.number_input("Rasio DPT Kelurahan", min_value=0.0, value=float(cur_tps["rasio_dpt_terhadap_penduduk_kelurahan"]), step=0.01)
                    e_pnd = st.number_input("Pendapatan Per Kapita", min_value=0.0, value=float(cur_tps["pendapatan_per_kapita"]), step=10000.0)
                with c2:
                    e_png = st.number_input("Tingkat Pengangguran (%)", min_value=0.0, value=float(cur_tps["tingkat_pengangguran"]), step=0.01)
                    e_kpd = st.number_input("Kepadatan Penduduk", min_value=0.0, value=float(cur_tps["kepadatan_penduduk"]), step=10.0)
                    e_ipm = st.number_input("IPM", min_value=0.0, value=float(cur_tps["ipm"]), step=0.01)
                    e_u1 = st.number_input("Pemilih Usia 17-24 (%)", min_value=0.0, value=float(cur_tps["persen_usia_17_24_kec"]), step=0.1)
                c_sub1, c_sub2 = st.columns(2)
                with c_sub1:
                    sub_upd = st.form_submit_button("Simpan Perubahan", use_container_width=True, type="primary")
                with c_sub2:
                    can_upd = st.form_submit_button("Batal", use_container_width=True)
                    
                if sub_upd:
                    if e_pl > e_dpt:
                        st.error("Pengguna hak pilih tidak boleh melebihi DPT.")
                    else:
                        upd_data = {
                            "tahun_pemilu": e_th, "kecamatan": cur_tps["kecamatan"], "kelurahan": cur_tps["kelurahan"],
                            "no_tps": cur_tps["no_tps"], "dpt": e_dpt, "pengguna_hak_pilih": e_pl,
                            "rasio_dpt_terhadap_penduduk_kelurahan": e_rs, "pendapatan_per_kapita": e_pnd,
                            "tingkat_pengangguran": e_png, "kepadatan_penduduk": e_kpd, "ipm": e_ipm,
                            "persen_usia_17_24_kec": e_u1, "persen_usia_25_44_kec": cur_tps["persen_usia_25_44_kec"],
                            "persen_usia_45_plus_kec": cur_tps["persen_usia_45_plus_kec"]
                        }
                        if update_tps_record(edit_id, upd_data):
                            st.success("Perubahan data transaksi berhasil disimpan.")
                            set_view("index")
                        else:
                            st.error("Gagal memperbarui transaksi TPS.")
                if can_upd:
                    set_view("index")

    # --- VIEW: INDEX ---
    else:
        c_title, c_btn = st.columns([3, 1])
        with c_title:
            st.markdown("### Transaksi Partisipasi Pemilu TPS")
            st.caption("Rekam jejak kehadiran pemilih dan indikator sosial ekonomi per TPS.")
        with c_btn:
            if st.button("Input Transaksi Baru", type="primary", use_container_width=True):
                set_view("create")
                
        # Filter Bar
        c_f1, c_f2, c_f3 = st.columns([1, 1, 1])
        with c_f1:
            sel_yr = st.selectbox("Tahun Pemilu:", [2019, 2024, 2029], index=1)
        with c_f2:
            sel_kc = st.selectbox("Kecamatan:", ["Semua Kecamatan"] + kec_options)
        with c_f3:
            q_tps = st.text_input("Cari TPS / Kelurahan:", placeholder="Contoh: 001 atau Basirih")
            
        with sqlite3.connect(DB_PATH) as conn:
            q_sql = "SELECT id, tahun_pemilu, kecamatan, kelurahan, no_tps, dpt, pengguna_hak_pilih, partisipasi_politik, ipm, tingkat_pengangguran, kepadatan_penduduk FROM data_partisipasi_tps WHERE tahun_pemilu = ?"
            params = [sel_yr]
            if sel_kc != "Semua Kecamatan":
                q_sql += " AND kecamatan = ?"
                params.append(sel_kc)
            df_tps = pd.read_sql_query(q_sql, conn, params=params)
            
        if q_tps and q_tps.strip():
            kw = q_tps.strip()
            df_tps = df_tps[
                (df_tps["no_tps"] == kw) |
                (df_tps["no_tps"] == kw.zfill(3)) |
                df_tps["kelurahan"].str.contains(kw, case=False, na=False)
            ]
            
        if not df_tps.empty:
            t_tot_tps = len(df_tps)
            t_tot_dpt = int(df_tps["dpt"].sum())
            t_tot_hadir = int(df_tps["pengguna_hak_pilih"].sum())
            t_avg_part = (t_tot_hadir / t_tot_dpt * 100.0) if t_tot_dpt > 0 else 0.0
            c_m1, c_m2, c_m3, c_m4 = st.columns(4)
            with c_m1:
                st.html(custom_metric_card("TPS TERFILTER", f"{t_tot_tps:,}".replace(",", "."), "", f"Tahun {sel_yr}", "neutral"))
            with c_m2:
                st.html(custom_metric_card("TOTAL DPT", f"{t_tot_dpt:,}".replace(",", "."), "", "Pemilih Terdaftar", "neutral"))
            with c_m3:
                st.html(custom_metric_card("TOTAL HADIR", f"{t_tot_hadir:,}".replace(",", "."), "", "Menggunakan Hak Pilih", "neutral"))
            with c_m4:
                st.html(custom_metric_card("RATA-RATA", f"{t_avg_part:.2f}%", "", "Partisipasi TPS", "up" if t_avg_part >= 77.5 else "neutral"))
            st.markdown("<br>", unsafe_allow_html=True)

        disp_tps = df_tps.rename(columns={
            "id": "ID", "tahun_pemilu": "Tahun", "kecamatan": "Kecamatan", "kelurahan": "Kelurahan",
            "no_tps": "No TPS", "dpt": "DPT", "pengguna_hak_pilih": "Hadir",
            "partisipasi_politik": "Partisipasi (%)", "ipm": "IPM", "tingkat_pengangguran": "Pengangguran (%)",
            "kepadatan_penduduk": "Kepadatan"
        })
        disp_tps["Partisipasi (%)"] = disp_tps["Partisipasi (%)"].map("{:.2f}%".format)
        
        st.dataframe(disp_tps, use_container_width=True, hide_index=True)
        st.caption(f"Menampilkan: **{len(disp_tps):,} Baris Transaksi TPS**".replace(",", "."))
        
        render_export_and_template_buttons(
            df_tps,
            "Transaksi Partisipasi TPS",
            ["tahun_pemilu", "kecamatan", "kelurahan", "no_tps", "dpt", "pengguna_hak_pilih", "partisipasi_politik", "ipm", "tingkat_pengangguran", "kepadatan_penduduk"],
            {"tahun_pemilu": sel_yr, "kecamatan": "BANJARMASIN BARAT", "kelurahan": "BASIRIH", "no_tps": "001", "dpt": 250, "pengguna_hak_pilih": 200, "partisipasi_politik": 80.0, "ipm": 80.53, "tingkat_pengangguran": 6.56, "kepadatan_penduduk": 10550.0}
        )
        
        # Action Bar
        if not df_tps.empty:
            st.markdown("---")
            st.markdown("##### Aksi untuk Rekaman Terpilih:")
            c_sel, c_ed, c_del = st.columns([3, 1, 1])
            with c_sel:
                tps_opts = {f"TPS {r['no_tps']} Kel. {r['kelurahan']} (ID: {r['id']})": r['id'] for _, r in df_tps.head(100).iterrows()}
                pilih_id = st.selectbox("Pilih Rekaman:", list(tps_opts.keys()), label_visibility="collapsed")
                target_id = tps_opts[pilih_id]
            with c_ed:
                if st.button("Edit Data", use_container_width=True):
                    set_view("edit", target_id)
            with c_del:
                if st.button("Hapus Data", type="primary", use_container_width=True):
                    if delete_tps_record(target_id):
                        st.success("Rekaman transaksi berhasil dihapus.")
                        st.rerun()
                    else:
                        st.error("Gagal menghapus rekaman.")



# ====================================================================
# MODUL 9: TRANSAKSI SUARA PARTAI PER TPS
# ====================================================================
elif modul_pilihan == "Transaksi Perolehan Suara Partai":
    st.markdown("### Transaksi Perolehan Suara Partai Politik per TPS")
    st.caption("Pencatatan hasil perolehan suara partai politik di masing-masing titik TPS.")
    
    col_k1, col_k2, col_k3 = st.columns(3)
    with col_k1:
        kec_list = ["BANJARMASIN BARAT", "BANJARMASIN SELATAN", "BANJARMASIN TIMUR", "BANJARMASIN TENGAH", "BANJARMASIN UTARA"]
        sel_k = st.selectbox("Pilih Kecamatan:", kec_list)
    with col_k2:
        kel_list = get_kelurahannya_by_kecamatan(sel_k, 2024)
        sel_l = st.selectbox("Pilih Kelurahan:", kel_list if kel_list else ["Belum Ada"])
    with col_k3:
        tps_list = get_tps_by_kelurahan(sel_k, sel_l, 2024) if kel_list else []
        sel_t = st.selectbox("Pilih Nomor TPS:", tps_list if tps_list else ["Belum Ada"])
        
    if kel_list and tps_list:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute("""
                SELECT t.id_tps 
                FROM tps t
                JOIN kelurahan k ON t.id_kelurahan = k.id_kelurahan
                JOIN kecamatan kc ON k.id_kecamatan = kc.id_kecamatan
                WHERE t.no_tps = ? AND k.nama_kelurahan = ? AND kc.nama_kecamatan = ?
            """, (sel_t, sel_l, sel_k))
            row_t = c.fetchone()
            id_tps_sel = row_t[0] if row_t else None
            
        if id_tps_sel:
            with sqlite3.connect(DB_PATH) as conn:
                df_suara = pd.read_sql_query("""
                    SELECT 
                        p.id_partai,
                        p.nomor_urut,
                        p.singkatan,
                        p.nama_partai,
                        COALESCE(s.jumlah_suara, 0) AS jumlah_suara
                    FROM partai p
                    LEFT JOIN suara_partai_tps s ON p.id_partai = s.id_partai AND s.id_tps = ?
                    ORDER BY p.nomor_urut ASC
                """, conn, params=(id_tps_sel,))
                
            if crud_view == "edit":
                col_b, _ = st.columns([1, 4])
                with col_b:
                    if st.button("Kembali ke Tabel", use_container_width=True):
                        set_view("index")
                st.markdown(f"#### Form Input Suara Partai di TPS {sel_t} Kel. {sel_l}")
                inputs_suara = {}
                with st.form("form_update_suara"):
                    c_pt1, c_pt2 = st.columns(2)
                    mid = (len(df_suara) + 1) // 2
                    for idx, r in df_suara.iterrows():
                        label = f"No. {r['nomor_urut']} - {r['singkatan']} ({r['nama_partai']})"
                        col_target = c_pt1 if idx < mid else c_pt2
                        with col_target:
                            inputs_suara[r["id_partai"]] = st.number_input(label, min_value=0, value=int(r["jumlah_suara"]), step=1, key=f"inp_pt_{r['id_partai']}")
                    c_s1, c_s2 = st.columns(2)
                    with c_s1:
                        sub_suara = st.form_submit_button("Simpan Perolehan Suara", use_container_width=True, type="primary")
                    with c_s2:
                        can_suara = st.form_submit_button("Batal", use_container_width=True)
                    if sub_suara:
                        with sqlite3.connect(DB_PATH) as conn:
                            cur = conn.cursor()
                            for pid, v in inputs_suara.items():
                                cur.execute("SELECT id_suara FROM suara_partai_tps WHERE id_tps = ? AND id_partai = ?", (id_tps_sel, pid))
                                if cur.fetchone():
                                    cur.execute("UPDATE suara_partai_tps SET jumlah_suara = ? WHERE id_tps = ? AND id_partai = ?", (v, id_tps_sel, pid))
                                else:
                                    cur.execute("INSERT INTO suara_partai_tps (id_tps, id_partai, jumlah_suara) VALUES (?, ?, ?)", (id_tps_sel, pid, v))
                            conn.commit()
                        st.success(f"Perolehan suara partai di TPS {sel_t} berhasil disimpan.")
                        set_view("index")
                    if can_suara:
                        set_view("index")
            else:
                c_tbl, c_btn = st.columns([3, 1])
                with c_tbl:
                    st.markdown(f"##### Perolehan Suara di TPS {sel_t} Kelurahan {sel_l}")
                with c_btn:
                    if st.button("Input / Perbarui Suara", type="primary", use_container_width=True):
                        set_view("edit", id_tps_sel)
                        
                st.dataframe(
                    df_suara[["nomor_urut", "singkatan", "nama_partai", "jumlah_suara"]].rename(columns={
                        "nomor_urut": "No Urut", "singkatan": "Singkatan", "nama_partai": "Nama Partai", "jumlah_suara": "Suara Sah"
                    }),
                    use_container_width=True,
                    hide_index=True
                )
                total_suara = df_suara["jumlah_suara"].sum()
                st.caption(f"Total Suara Sah Terdata: **{total_suara:,} Suara**".replace(",", "."))
                render_export_and_template_buttons(
                    df_suara,
                    "Suara Partai TPS",
                    ["id_partai", "id_tps", "jumlah_suara"],
                    {"id_partai": 1, "id_tps": id_tps_sel, "jumlah_suara": 50}
                )
        else:
            st.info("TPS belum terdaftar di Master TPS.")


# ====================================================================
# MODUL 10: TRANSAKSI AGREGAT HISTORIS
# ====================================================================
elif modul_pilihan == "Transaksi Partisipasi Agregat":
    df_ag = get_all_data_agregat()
    
    if crud_view == "create":
        col_b, _ = st.columns([1, 4])
        with col_b:
            if st.button("Kembali ke Tabel", use_container_width=True):
                set_view("index")
        st.markdown("### Form Input Partisipasi Agregat")
        with st.form("form_create_agregat"):
            c1, c2 = st.columns(2)
            with c1:
                th_ag = st.number_input("Tahun Pemilu", min_value=1999, max_value=2050, value=2019)
                dp_ag = st.selectbox("Dapil", ["BANJARMASIN 1", "BANJARMASIN 2", "BANJARMASIN 3", "BANJARMASIN 4", "BANJARMASIN 5"])
                kc_ag = st.selectbox("Kecamatan", ["BANJARMASIN TENGAH", "BANJARMASIN UTARA", "BANJARMASIN TIMUR", "BANJARMASIN SELATAN", "BANJARMASIN BARAT"])
            with c2:
                dpt_ag = st.number_input("Total DPT", min_value=1, value=95000)
                pl_ag = st.number_input("Total Pengguna Hak Pilih", min_value=0, value=75000)
                sb_ag = st.text_input("Sumber Data", value="KPU Kota Banjarmasin").strip()
            cat_ag = st.text_input("Catatan", value="Rekapitulasi Pemilu Serentak").strip()
            c_s1, c_s2 = st.columns(2)
            with c_s1:
                sub_btn = st.form_submit_button("Simpan Agregat", use_container_width=True, type="primary")
            with c_s2:
                can_btn = st.form_submit_button("Batal", use_container_width=True)
            if sub_btn:
                if pl_ag > dpt_ag:
                    st.error("Pengguna hak pilih tidak boleh melebihi DPT.")
                else:
                    part_val = (float(pl_ag) / float(dpt_ag)) * 100.0
                    ag_data = {
                        "tahun_pemilu": th_ag, "dapil": dp_ag, "kecamatan": kc_ag,
                        "dpt_total": dpt_ag, "pengguna_total": pl_ag, "partisipasi_politik": part_val,
                        "sumber_data": sb_ag, "catatan": cat_ag
                    }
                    if add_data_agregat(ag_data):
                        st.success("Rekaman agregat berhasil disimpan.")
                        set_view("index")
                    else:
                        st.error("Gagal menyimpan data agregat.")
            if can_btn:
                set_view("index")

    else:
        c_title, c_btn = st.columns([3, 1])
        with c_title:
            st.markdown("### Transaksi Partisipasi Agregat Historis")
            st.caption("Rekapitulasi partisipasi pemilu tingkat Dapil / Kecamatan.")
        with c_btn:
            if st.button("Input Agregat Baru", type="primary", use_container_width=True):
                set_view("create")
                
        if df_ag.empty:
            st.info("Belum ada rekaman partisipasi agregat.")
        else:
            disp_ag = df_ag.rename(columns={
                "id": "ID", "tahun_pemilu": "Tahun", "dapil": "Dapil", "kecamatan": "Kecamatan",
                "dpt_total": "DPT Total", "pengguna_total": "Pengguna", "partisipasi_politik": "Partisipasi (%)",
                "sumber_data": "Sumber"
            })
            st.dataframe(disp_ag, use_container_width=True, hide_index=True)
            st.caption(f"Total: **{len(df_ag)} Rekaman Agregat**")
            render_export_and_template_buttons(
                df_ag,
                "Partisipasi Agregat",
                ["tahun_pemilu", "dapil", "kecamatan", "dpt_total", "pengguna_total", "partisipasi_politik", "sumber_data"],
                {"tahun_pemilu": 2019, "dapil": "BANJARMASIN 1", "kecamatan": "BANJARMASIN TENGAH", "dpt_total": 75000, "pengguna_total": 55000, "partisipasi_politik": 73.33, "sumber_data": "KPU Kota Banjarmasin"}
            )
            
            st.markdown("---")
            st.markdown("##### Aksi untuk Baris Terpilih:")
            c_sel, c_del = st.columns([4, 1])
            with c_sel:
                ag_opts = {f"Pemilu {r['tahun_pemilu']} - {r['kecamatan']} ({r['partisipasi_politik']:.2f}%) [ID: {r['id']}]": r['id'] for _, r in df_ag.iterrows()}
                pilih_id = st.selectbox("Pilih Rekaman Agregat:", list(ag_opts.keys()), label_visibility="collapsed")
                target_id = ag_opts[pilih_id]
            with c_del:
                if st.button("Hapus Data", type="primary", use_container_width=True):
                    if delete_data_agregat(target_id):
                        st.success("Rekaman agregat berhasil dihapus.")
                        st.rerun()
                    else:
                        st.error("Gagal menghapus rekaman.")


# ====================================================================
# MODUL 11: TRANSAKSI LOG PREDIKSI
# ====================================================================
elif modul_pilihan == "Transaksi Log Hasil Prediksi":
    df_hist = get_prediction_history()
    c_title, c_btn = st.columns([3, 1])
    with c_title:
        st.markdown("### Transaksi Log Hasil Prediksi (Simulasi Pengguna)")
        st.caption("Audit log setiap kali simulasi atau perkiraan wilayah TPS dijalankan.")
    with c_btn:
        if not df_hist.empty:
            if st.button("Bersihkan Seluruh Log", type="primary", use_container_width=True):
                if clear_all_predictions():
                    st.success("Seluruh log prediksi berhasil dibersihkan.")
                    st.rerun()
                    
    if df_hist.empty:
        st.info("Belum ada riwayat transaksi log prediksi.")
    else:
        disp_hist = df_hist.rename(columns={
            "id_prediksi": "ID", "kecamatan": "Kecamatan", "kelurahan": "Kelurahan", "no_tps": "No TPS",
            "dpt": "DPT", "ipm": "IPM", "hasil_prediksi": "Hasil Prediksi (%)", "created_at": "Waktu Simulasi"
        })
        disp_hist["Hasil Prediksi (%)"] = disp_hist["Hasil Prediksi (%)"].apply(lambda x: f"{x:.2f}%" if isinstance(x, (int, float)) else x)
        st.dataframe(disp_hist, use_container_width=True, hide_index=True)
        st.caption(f"Total: **{len(df_hist)} Log Tersimpan**")
        render_export_and_template_buttons(
            df_hist,
            "Log Prediksi",
            ["kecamatan", "kelurahan", "no_tps", "dpt", "hasil_prediksi"],
            {"kecamatan": "BANJARMASIN BARAT", "kelurahan": "BASIRIH", "no_tps": "001", "dpt": 250, "hasil_prediksi": 78.50}
        )
        
        st.markdown("---")
        st.markdown("##### Hapus Log Tertentu:")
        c_sel, c_del = st.columns([4, 1])
        with c_sel:
            log_opts = {f"ID {r['id_prediksi']} - TPS {r['no_tps']} {r['kelurahan']} ({r['created_at']})": r['id_prediksi'] for _, r in df_hist.iterrows()}
            pilih_id = st.selectbox("Pilih Log:", list(log_opts.keys()), label_visibility="collapsed")
            target_id = log_opts[pilih_id]
        with c_del:
            if st.button("Hapus Log", type="primary", use_container_width=True):
                if delete_prediction(target_id):
                    st.success("Log berhasil dihapus.")
                    st.rerun()


# ====================================================================
# MODUL 12: TRANSAKSI LOG EVALUASI MODEL
# ====================================================================
elif modul_pilihan == "Transaksi Log Evaluasi Model":
    df_evals = get_all_model_evaluations()
    st.markdown("### Transaksi Log Evaluasi Model Random Forest")
    st.caption("Pencatatan metrik performa algoritma Machine Learning dari waktu ke waktu.")
    
    if df_evals.empty:
        st.info("Belum ada rekaman riwayat evaluasi model di basis data.")
    else:
        disp_eval = df_evals.rename(columns={
            "id_evaluasi": "ID", "nama_model": "Nama Model", "rmse": "RMSE", "mae": "MAE",
            "r2_score": "R² Score", "jumlah_data": "Total Data", "jumlah_training": "Sampel Latih",
            "jumlah_testing": "Sampel Uji", "tanggal_evaluasi": "Waktu Pelatihan"
        })
        st.dataframe(disp_eval, use_container_width=True, hide_index=True)
        st.caption(f"Total: **{len(df_evals)} Catatan Evaluasi**")
        render_export_and_template_buttons(
            df_evals,
            "Log Evaluasi Model",
            ["nama_model", "rmse", "mae", "r2_score", "jumlah_data"],
            {"nama_model": "Random Forest", "rmse": 4.25, "mae": 3.12, "r2_score": 0.785, "jumlah_data": 460}
        )
        
        st.markdown("---")
        st.markdown("##### Hapus Log Evaluasi:")
        c_sel, c_del = st.columns([4, 1])
        with c_sel:
            ev_opts = {f"ID {r['id_evaluasi']} - {r['nama_model']} ({r['tanggal_evaluasi']})": r['id_evaluasi'] for _, r in df_evals.iterrows()}
            pilih_id = st.selectbox("Pilih Log Evaluasi:", list(ev_opts.keys()), label_visibility="collapsed")
            target_id = ev_opts[pilih_id]
        with c_del:
            if st.button("Hapus Log", type="primary", use_container_width=True):
                if delete_model_evaluation(target_id):
                    st.success("Log evaluasi berhasil dihapus.")
                    st.rerun()


# ====================================================================
# MODUL 13: PUSAT IMPOR & SINKRONISASI RELASIONAL
# ====================================================================
elif modul_pilihan == "Pusat Impor & Sinkronisasi":
    st.markdown("### Pusat Impor Massal CSV & Sinkronisasi Relasional")
    st.caption("Menjamin integrasi dan keutuhan relasi basis data antara transaksi pemilu dan tabel master.")
    
    stats = get_database_summary_stats()
    c1, c2 = st.columns(2)
    
    with c1:
        st.markdown(
            """
            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px;">
                <h4 style="margin: 0 0 10px 0; color: #1e293b;">Impor Dataset CSV Pemilu KPU</h4>
                <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 12px;">Unggah file CSV dataset TPS untuk memperbarui data pemilu di database.</p>
            </div>
            """,
            unsafe_allow_html=True
        )
        up_file = st.file_uploader("Pilih file CSV dataset KPU", type=["csv"], key="csv_import_clean")
        if up_file is not None:
            try:
                import_df = pd.read_csv(up_file)
                import_df.columns = (
                    import_df.columns.astype(str)
                    .str.strip().str.lower().str.replace(" ", "_", regex=False).str.replace("-", "_", regex=False)
                )
                required = ["tahun_pemilu", "kecamatan", "kelurahan", "no_tps", "partisipasi_politik"]
                missing = [c for c in required if c not in import_df.columns]
                if missing:
                    st.error(f"Gagal Impor: Kolom wajib '{', '.join(missing)}' tidak ditemukan.")
                else:
                    success_count = 0
                    with get_connection() as conn:
                        cursor = conn.cursor()
                        years = [int(float(y)) for y in import_df["tahun_pemilu"].dropna().unique().tolist()]
                        for y in years:
                            cursor.execute("DELETE FROM data_partisipasi_tps WHERE tahun_pemilu = ?", (y,))
                        for _, row in import_df.iterrows():
                            th = row.get("tahun_pemilu")
                            kc = row.get("kecamatan")
                            kl = row.get("kelurahan")
                            tp = row.get("no_tps")
                            if pd.isna(th) or pd.isna(kc) or pd.isna(kl) or pd.isna(tp):
                                continue
                            def clean_flt(v):
                                try: return float(str(v).replace(",", "")) if not pd.isna(v) else None
                                except Exception: return None
                            def clean_i(v):
                                try: return int(float(str(v).replace(",", ""))) if not pd.isna(v) else None
                                except Exception: return None
                            dpt = clean_i(row.get("dpt"))
                            pl = clean_i(row.get("pengguna_hak_pilih"))
                            part = min(100.0, (float(pl)/float(dpt))*100.0) if dpt and pl else clean_flt(row.get("partisipasi_politik"))
                            cursor.execute("""
                                INSERT INTO data_partisipasi_tps (
                                    tahun_pemilu, level_data, kecamatan, kelurahan, no_tps, id_record,
                                    dpt, pengguna_hak_pilih, partisipasi_politik, dpt_total_tps,
                                    penduduk_total_kelurahan, penduduk_total_kecamatan, rasio_dpt_terhadap_penduduk_kelurahan,
                                    pendapatan_per_kapita, tingkat_pengangguran, kepadatan_penduduk, ipm,
                                    jumlah_usia_17_24_kec, jumlah_usia_25_44_kec, jumlah_usia_45_plus_kec,
                                    persen_usia_17_24_kec, persen_usia_25_44_kec, persen_usia_45_plus_kec
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """, (
                                int(th), 'tps', str(kc).strip().upper(), str(kl).strip().upper(), str(tp).strip(),
                                f"{th}-{kc}-{kl}-{tp}".strip().upper(), dpt, pl, part, dpt,
                                str(row.get("penduduk_total_kelurahan", "")), clean_i(row.get("penduduk_total_kecamatan")),
                                clean_flt(row.get("rasio_dpt_terhadap_penduduk_kelurahan")), clean_flt(row.get("pendapatan_per_kapita")),
                                clean_flt(row.get("tingkat_pengangguran")), clean_flt(row.get("kepadatan_penduduk")),
                                clean_flt(row.get("ipm")), clean_i(row.get("jumlah_usia_17_24_kec")),
                                clean_i(row.get("jumlah_usia_25_44_kec")), clean_i(row.get("jumlah_usia_45_plus_kec")),
                                clean_flt(row.get("persen_usia_17_24_kec")), clean_flt(row.get("persen_usia_25_44_kec")),
                                clean_flt(row.get("persen_usia_45_plus_kec"))
                            ))
                            success_count += 1
                        conn.commit()
                        seed_relational_tables_from_tps()
                    st.success(f"Berhasil mengimpor {success_count} data TPS dan menyinkronkan Master Data.")
                    st.rerun()
            except Exception as e:
                st.error(f"Gagal memproses berkas: {e}")
                
    with c2:
        st.markdown(
            """
            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px;">
                <h4 style="margin: 0 0 10px 0; color: #1e293b;">Sinkronisasi Relasional Otomatis</h4>
                <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 12px;">Pindai data transaksi TPS dan daftarkan Kecamatan, Kelurahan, serta Nomor TPS ke Master Data tanpa duplikasi.</p>
            </div>
            """,
            unsafe_allow_html=True
        )
        if st.button("Jalankan Sinkronisasi Sekarang", type="primary", use_container_width=True):
            try:
                seed_relational_tables_from_tps()
                st.success("Sinkronisasi Master Relasional selesai 100%.")
                st.rerun()
            except Exception as e:
                st.error(f"Gagal sinkronisasi: {e}")
                
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("##### Ringkasan Status Basis Data:")
        st.markdown(
            f"""
            - **Total Master Kecamatan**: `{stats['master_kecamatan']} Wilayah`
            - **Total Master Kelurahan**: `{stats['master_kelurahan']} Wilayah`
            - **Total Master Titik TPS**: `{stats['master_tps']:,} Titik`
            - **Total Transaksi Partisipasi**: `{stats['transaksi_tps']:,} Baris`
            - **Integritas Foreign Keys**: `ON (Enforced)`
            """.replace(",", ".")
        )

    st.markdown("---")
    st.markdown("### Cadangan & Diagnostik Integritas Basis Data")
    c_bk1, c_bk2 = st.columns(2)
    
    with c_bk1:
        st.markdown(
            """
            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-bottom: 12px;">
                <h4 style="margin: 0 0 10px 0; color: #1e293b;">Cadangkan Basis Data SQLite (Backup)</h4>
                <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 12px;">Unduh seluruh file basis data sistem (polpart.db) sebagai arsip cadangan offline.</p>
            </div>
            """,
            unsafe_allow_html=True
        )
        try:
            from pathlib import Path
            db_bytes = Path(DB_PATH).read_bytes()
            st.download_button(
                "Unduh File Basis Data (polpart.db)",
                data=db_bytes,
                file_name="polpart_backup.db",
                mime="application/x-sqlite3",
                use_container_width=True,
                type="primary"
            )
        except Exception as e:
            st.error(f"Gagal membaca file basis data: {e}")
            
    with c_bk2:
        st.markdown(
            """
            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-bottom: 12px;">
                <h4 style="margin: 0 0 10px 0; color: #1e293b;">Audit Diagnostik Integritas Relasional</h4>
                <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 12px;">Pindai dan verifikasi integritas relasi foreign keys serta catatan yatim di seluruh tabel.</p>
            </div>
            """,
            unsafe_allow_html=True
        )
        if st.button("Jalankan Audit Diagnostik Integritas", use_container_width=True):
            diag = check_database_integrity()
            if diag["is_healthy"]:
                st.success(f"Hasil Audit: Basis Data {diag['status']}. Nol pelanggaran foreign keys terdeteksi.")
            else:
                st.warning(f"Hasil Audit: {diag['status']}. Ditemukan inkonsistensi foreign keys.")
            st.markdown(
                f"""
                - **Pelanggaran Foreign Keys**: `{diag['fk_violations']}`
                - **Kelurahan Tanpa Kecamatan (Orphan)**: `{diag['orphan_kelurahan']}`
                - **TPS Tanpa Kelurahan (Orphan)**: `{diag['orphan_tps']}`
                - **Status Relasional**: `{diag['status']}`
                """
            )

