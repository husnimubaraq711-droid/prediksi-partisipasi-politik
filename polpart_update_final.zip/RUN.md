# Panduan Menjalankan Sistem PolPart RF
## Sistem Analisis & Prediksi Partisipasi Politik Kota Banjarmasin

Dokumen ini berisi panduan lengkap langkah demi langkah untuk menjalankan aplikasi PolPart RF dari terminal hingga antarmuka web terbuka di peramban.

---

### Prasyarat Sistem
* **Python**: Versi 3.10, 3.11, atau 3.12 telah terpasang di komputer.
* **Koneksi Internet**: Diperlukan saat pertama kali menginstal pustaka dependensi (Langkah 3).
* **Sistem Operasi**: Windows 10/11 (atau macOS / Linux).

---

### Langkah Demi Langkah Menjalankan Aplikasi

#### Langkah 1: Buka Terminal di Direktori Proyek
1. Buka folder hasil ekstraksi zip di File Explorer.
2. Klik kanan di area kosong folder, lalu pilih **"Open in Terminal"** (PowerShell / Command Prompt).
3. Pastikan path terminal berada di folder proyek, contoh:
   ```text
   D:\000. IT\11. TA\polpart>
   ```

---

#### Langkah 2: Buat & Aktifkan Virtual Environment
Jalankan perintah berikut untuk mengisolasi paket pustaka Python:

1. **Membuat Virtual Environment:**
   ```powershell
   python -m venv venv
   ```

2. **Mengaktifkan Virtual Environment:**
   * **Jika menggunakan Windows PowerShell:**
     ```powershell
     .\venv\Scripts\Activate.ps1
     ```
     > **Catatan Troubleshoot PowerShell:**
     > Jika muncul pesan error warna merah terkait script execution policy, ketik perintah berikut terlebih dahulu:
     > ```powershell
     > Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
     > ```
     > Setelah itu, ulangi perintah `.\venv\Scripts\Activate.ps1`.

   * **Jika menggunakan Command Prompt (CMD):**
     ```cmd
     .\venv\Scripts\activate.bat
     ```

   * **Jika menggunakan macOS / Linux:**
     ```bash
     source venv/bin/activate
     ```

*Tanda virtual environment berhasil aktif adalah munculnya teks `(venv)` di sisi paling kiri baris perintah.*

---

#### Langkah 3: Pasang Pustaka Dependensi
Jalankan perintah ini untuk menginstal seluruh pustaka yang dibutuhkan:
```powershell
pip install -r requirements.txt
```
*(Tunggu hingga proses instalasi pustaka streamlit, scikit-learn, plotly, dll. selesai).*

---

#### Langkah 4: Jalankan Aplikasi Web
Setelah seluruh instalasi dependensi selesai, jalankan perintah:
```powershell
streamlit run app.py
```
*(Atau gunakan alternatif perintah: `python -m streamlit run app.py`)*.

---

#### Langkah 5: Buka di Peramban Web (Browser)
Aplikasi akan secara otomatis membuka jendela browser default Anda. Jika tidak terbuka otomatis, buka Google Chrome, Microsoft Edge, atau Mozilla Firefox lalu kunjungi alamat:
```text
http://localhost:8501
```

---

### Akun Login Bawaan Sistem
Gunakan akun login yang telah terdaftar di basis data relasional:

| Peran (Role) | Username | Password | Keterangan Hak Akses |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin` | `admin123` | Akses penuh ke seluruh fitur dan menu Kelola Data |
| **Petugas KPU** | `kpu` | `kpu123` | Akses manajemen data TPS, prediksi, dan visualisasi |
| **Pengguna Umum** | `user` | `user123` | Akses eksplorasi data historis, grafik, dan prediksi |
| **Bakesbangpol** | `bakesbangpol` | `bakesbangpol123` | Akses analisis partisipasi politik instansi terkait |
| **BPS** | `bps` | `bps123` | Akses indikator data demografi dan statistik |
| **Dukcapil** | `dukcapil` | `dukcapil123` | Akses data kependudukan dan DPT wilayah |

---

### Menjalankan Ulang di Lain Waktu (Cukup 2 Perintah)
Jika virtual environment dan library sudah pernah dipasang sebelumnya di komputer tersebut, Anda cukup membuka terminal di folder proyek dan menjalankan dua baris ini:
```powershell
.\venv\Scripts\Activate.ps1
streamlit run app.py
```

---

### Cara Menghentikan Aplikasi
Untuk mematikan server lokal yang sedang berjalan:
* Tekan tombol kombinasi **`Ctrl + C`** pada jendela terminal.
